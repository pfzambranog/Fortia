Create Or Replace Procedure sp_alta_sueldos_ING_WD
   (PsCompania        Char,
    PsTrabajador      Char,
    PsFecha_sueldo    Char,
    PnSalario         Number,
    PsCausa_Aumento   Char,
    PnLinea           Number)
As
   w_trabajador             Char(10)      := Lpad(trim(PsTrabajador), 10, ' ');
   w_error                  Number(1, 0)  := 0;
   w_desc_error             Varchar2(250);
   w_proceso                Varchar2(030) := 'ARCHIVO SUELDO.TXT';
   w_archivo                Varchar2(030) := 'SUELDO.TXT';
   w_y                      Number(1, 0)  := 1;
   w_linea                  Number(4, 0);
   w_secuencia              Number(4, 0);
   w_fecha                  Date;
   w_causa_aumento          Char(2);

Begin
   Begin
      Select distinct 1
      Into   w_y
      From   bitacora_carga_ing_WD
      Where  Proceso = w_archivo
      And    Rownum  < 2;
      Exception When no_data_found Then
        w_y := 0;
   End;
   
   If w_y = 0 Then
      Insert Into bitacora_carga_ing_WD
      Select w_archivo, 1, 0, 0
      From   Dual;
   Else
      w_y := 0;
      Update bitacora_carga_ing_WD
      Set    Registros_leidos = registros_leidos + 1
      Where  Proceso = w_archivo;
   End If;

   Commit;

   Begin
      Select to_date(Psfecha_sueldo, 'dd/mm/yyyy')
      Into   w_fecha
      From   dual;
      Exception when Others Then
         w_error      := 1;
         w_desc_error := 'FORMATO DE FECHA DE SUELDO NO VALIDO';
         Goto Error;
   End;

   Begin
      Select 1
      Into   w_y
      From   Companias
      Where  Compania = PsCompania
      And    Rownum   < 2;
      Exception When no_data_found Then
         w_error      := 1;
         w_desc_error := 'CODIGO DE COMPA��A NO VALIDO.: ' ||Nvl(PsCompania, ' ' );
         Goto Error;
   End;

--
-- Se genera una actualizaci�n para que tome como causa de aumento la que esta por defecto.
--

--
-- Se modifica a petici�n de Yaneth el 21/12/2015
--

   Begin
      Select Substr(alfanumerico, 1, 2)
      Into   w_causa_aumento
      From   parametros_rh
      Where  compania            = PsCompania
      And    parametro_rh        = 'Causa_Aum'
      And    secuencia_parametro = 1;
      Exception When no_data_found Then
         w_causa_aumento := ' ';
   End;

   Begin
      Select 1
      Into   w_y
      From   causas_aumento
      Where  Causa_aumento = PsCausa_Aumento
      And    Rownum        < 2;
      Exception When no_data_found Then
         w_y := 0;
   End;
   
   If w_y = 1 Then
      w_causa_aumento := PsCausa_Aumento;
   End If;

   Begin
      Select linea
      Into   w_linea
      From   sueldos_ING_WD
      Where  Compania   = PsCompania
      And    Trabajador = w_Trabajador
      And    Rownum     < 2;
      Exception When no_data_found Then
            w_linea := 0;
   End;
   
   If w_linea > 0 Then
      w_error := 1;
      w_desc_error := 'CODIGO DE TRABAJADOR PRESENTE ANTERIORMENTE EN LA L�NEA '||to_char(w_linea);
      Goto Error;
   End If;
   
   Select Max(secuencia)
   Into   w_secuencia
   From   sueldos_ING_WD
   Where  Compania   = PsCompania
   And    Trabajador = w_Trabajador
   And    Fecha      = w_Fecha;
   
   w_secuencia := Nvl(w_secuencia, 0) + 1;
   
   Begin
      Insert Into sueldos_ING_WD
     (compania, trabajador, fecha, secuencia, salario, causa_aumento, grupo_salario, Linea)
      Select PsCompania, w_trabajador, w_fecha, w_secuencia, PnSalario, w_causa_aumento, 0, PnLinea
      From   Dual;
      
      Update bitacora_carga_ing_WD
      Set    Registros_validos  = Registros_validos  + 1
      Where  Proceso = w_archivo;

      Exception When Others Then
         Rollback;
         w_error      := 1;
         w_desc_error := 'ERRROR AL INSERTAR REGISTRO.: '||to_char(sqlcode)||'-'||Substr(sqlerrm, 1, 150);
   End;
   
<<Error>>

   If w_error > 0 Then
      sp_alta_errores_datos_ing_WD(w_Proceso, Pstrabajador, PnLinea, w_desc_error);
      Update bitacora_carga_ing_WD
      Set    Registros_error = Registros_error + 1
      Where  Proceso = w_archivo;

   End If;
   
   Commit;
   Return;

End sp_alta_sueldos_ING_WD;
/

Create Or Replace Public Synonym sp_alta_sueldos_ING_WD for sp_alta_sueldos_ING_WD;
Grant Execute on sp_alta_sueldos_ING_WD to Adama;
