Create Or Replace Procedure sp_alta_trab_gral_ing_prod_dw
As

   w_compania       Char(4);
   w_trabajador     Char(10);
   w_x              Number(1, 0);
   w_y              Number(1, 0);
   w_error          Number(1, 0)  := 0;
   w_sql            Varchar2(4000);
   w_comilla        Char(1) := Chr(39);
   w_desc_error     Varchar2(250);
   w_proceso        Varchar2(040) := 'ARCHIV TRABAJADORES_GRALES.TXT';
   w_archivo        Varchar2(040) := 'TRABAJADORES_GRALES.TXT';

  
   Cursor C_trab_new Is
   Select *
   From   trabajadores_grales_ING_WD
   Order  by Linea;
   
   Cursor C_trabajadores Is
   Select *
   From   trabajadores_grales
   Where  Compania   = w_compania
   And    Trabajador = w_trabajador;

Begin

   For X1 in C_trab_new Loop

       w_compania   := x1.compania;
       w_trabajador := x1.trabajador;
       w_error      := 0;
 
       Begin
          Select Distinct 1
          Into   w_x
          From   Trabajadores
          Where  Trabajador = w_trabajador
          And    Rownum      < 2;
          Exception When no_data_Found Then
             w_x     := 0;
             w_error := 1;
             w_desc_error := 'CODIGO DE TRABAJADOR NO EXISTE EN TRABAJADORES.';
             sp_alta_errores_datos_ing_WD(w_Proceso, x1.trabajador, x1.Linea, w_desc_error);
             Update bitacora_carga_ing_WD
             Set    Registros_error = Registros_error + 1
             Where  Proceso = w_archivo;
             Commit;
       End;

       If w_error = 0 Then
          Begin
             Select Distinct 1
             Into   w_x
             From   Trabajadores_grales
             Where  Compania   = x1.compania
             And    Trabajador = x1.trabajador
             And    Rownum      < 2;
             Exception When no_data_found Then
                w_x := 0;
          End;
       
          If w_x = 0 Then
             Begin
                Insert Into Trabajadores_grales
                (compania,         trabajador,       fecha_ingreso,        fecha_antiguedad, fecha_vto_contrato,
                 relacion_laboral, telefono_oficina, extension_telefonica, clase_nomina,     sistema_antiguedad,
                 sistema_horario,  turno,            forma_pago,           sit_trabajador,   fecha_ini_contrato, plazo)             
                Select x1.compania,         x1.trabajador,       x1.fecha_ingreso,        x1.fecha_antiguedad, x1.fecha_vto_contrato,
                       x1.relacion_laboral, x1.telefono_oficina, x1.extension_telefonica, x1.clase_nomina,     x1.sistema_antiguedad,
                       x1.sistema_horario,  x1.turno,            x1.forma_pago,           x1.sit_trabajador,   x1.fecha_ini_contrato, x1.plazo
                From   Dual;
                Commit;
                Exception When Others Then
                   Rollback;
                   w_desc_error := 'ERRROR AL INSERTAR REGISTRO.: '||to_char(sqlcode)||'-'||Substr(sqlerrm, 1, 150);
                   sp_alta_errores_datos_ing_WD(w_Proceso, x1.trabajador, x1.Linea, w_desc_error);
                   Update bitacora_carga_ing_WD
                   Set    Registros_error = Registros_error + 1
                   Where  Proceso = w_archivo;
             End;
             Commit;
          Else
             Begin
                For X2 In C_Trabajadores Loop
             
                    If Nvl(x1.clase_nomina, ' ') <> Nvl(x2.clase_nomina, ' ') Then
                       w_error      := 0;
                       w_desc_error := Null;
                       Sp_ing_valida_transacciones (x1.compania, x1.compania, w_error, w_desc_error);
                       If w_error <> 0 Then
                          sp_alta_errores_datos_ing_WD(w_Proceso, x1.trabajador, x1.Linea, w_desc_error);
                          Update bitacora_carga_ing_WD
                          Set    Registros_error = Registros_error + 1
                          Where  Proceso = w_archivo;
                          Commit;
                       End If;
                    End If;
                 
                    If w_error = 0 Then
                       w_sql := 'Update Trabajadores_grales ' ||
                                'Set    ';
                       w_y := 0;
                 
                       If Nvl(x1.fecha_ingreso, Sysdate) <> Nvl(x2.fecha_ingreso, Sysdate) Then
                          w_y := 1;
                          w_sql := w_sql||' fecha_ingreso = ';
                          If x1.fecha_ingreso Is  Null Then
                             w_sql := w_sql||' Null ';
                          Else 
                             w_sql := w_sql||w_comilla||trim(x1.fecha_ingreso)||w_comilla;
                          End If;
                       End If;
                 
                       If Nvl(x1.fecha_antiguedad, Sysdate) <> Nvl(x2.fecha_antiguedad, Sysdate) Then
                          If w_y = 1 Then
                             w_sql := w_sql ||', ';
                          Else
                             w_y := 1;
                          End If;
                    
                          w_sql := w_sql||' fecha_antiguedad = ';
                          If x1.fecha_antiguedad Is Null Then
                             w_sql := w_sql||' Null ';
                          Else
                             w_sql := w_sql ||w_comilla||to_char(x1.fecha_antiguedad)||w_comilla;
                          End If;
                       End If;
                
                       If Nvl(x1.fecha_vto_contrato, Sysdate) <> Nvl(x2.fecha_vto_contrato, Sysdate) Then
                          If w_y = 1 Then
                             w_sql := w_sql ||', ';
                          Else
                             w_y := 1;
                          End If;
                    
                          w_sql := w_sql||' fecha_fecha_vto_contrato = ';
                          If x1.fecha_vto_contrato Is Null Then
                             w_sql := w_sql||' Null ';
                          Else
                             w_sql := w_sql ||w_comilla||to_char(x1.fecha_vto_contrato)||w_comilla;
                          End If;
                       End If;
                 
                       If Nvl(x1.relacion_laboral, ' ') <> Nvl(x2.relacion_laboral, ' ') Then
                          If w_y = 1 Then
                             w_sql := w_sql ||', ';
                          Else
                             w_y := 1;
                          End If;
                    
                          w_sql := w_sql||' relacion_laboral = ';
                          If x1.relacion_laboral Is Null Then
                             w_sql := w_sql||' Null ';
                          Else
                             w_sql := w_sql ||w_comilla||trim(x1.relacion_laboral)||w_comilla;
                          End If;
                       End If;
                 
                       If Nvl(x1.telefono_oficina, ' ') <> Nvl(x2.telefono_oficina, ' ') Then
                          If w_y = 1 Then
                             w_sql := w_sql ||', ';
                          Else
                             w_y := 1;
                          End If;
                     
                          w_sql := w_sql||' telefono_oficina = ';
                          If x1.telefono_oficina Is Null Then
                             w_sql := w_sql||' Null ';
                          Else
                             w_sql := w_sql ||w_comilla||trim(x1.telefono_oficina)||w_comilla;
                          End If;
                       End If;
                 
                       If Nvl(x1.extension_telefonica, 0) <> Nvl(x2.extension_telefonica, 0) Then
                          If w_y = 1 Then
                             w_sql := w_sql ||', ';
                          Else
                             w_y := 1;
                          End If;
                    
                          w_sql := w_sql||' extension_telefonica = ';
                          If x1.extension_telefonica Is Null Then
                             w_sql := w_sql||' Null ';
                          Else
                             w_sql := w_sql ||to_char(x1.extension_telefonica);
                          End If;
                       End If;
                 
                       If Nvl(x1.clase_nomina, ' ') <> Nvl(x2.clase_nomina, ' ') Then
                          If w_y = 1 Then
                             w_sql := w_sql ||', ';
                          Else
                             w_y := 1;
                          End If;
                    
                          w_sql := w_sql||' clase_nomina = ';
                          If x1.clase_nomina Is Null Then
                             w_sql := w_sql||' Null ';
                          Else
                            w_sql := w_sql ||w_comilla||trim(x1.clase_nomina)||w_comilla;
                          End If;
                       End If;
                 
                       If Nvl(x1.sistema_antiguedad, 0) <> Nvl(x2.sistema_antiguedad, 0) Then
                          If w_y = 1 Then
                             w_sql := w_sql ||', ';
                          Else
                             w_y := 1;
                          End If;
                    
                          w_sql := w_sql||' sistema_antiguedad = ';
                          If trim(x1.sistema_antiguedad) Is Null Then
                             w_sql := w_sql||' Null ';
                          Else
                             w_sql := w_sql ||to_char(x1.sistema_antiguedad);
                          End If;
                       End If;
             
                       If Nvl(x1.sistema_horario, 0) <> Nvl(x2.sistema_horario, 0) Then
                          If w_y = 1 Then
                             w_sql := w_sql ||', ';
                          Else
                             w_y := 1;
                          End If;
                    
                          w_sql := w_sql||' sistema_horario = ';
                          If x1.sistema_horario Is Null Then
                             w_sql := w_sql||' Null ';
                          Else
                             w_sql := w_sql ||to_char(x1.sistema_horario);
                          End If;
                       End If;

                       If Nvl(x1.turno, 0) <> Nvl(x2.turno, 0) Then
                          If w_y = 1 Then
                             w_sql := w_sql ||', ';
                          Else
                             w_y := 1;
                          End If;
                    
                          w_sql := w_sql||' turno = ';
                          If x1.turno Is Null Then
                             w_sql := w_sql||' Null ';
                          Else
                             w_sql := w_sql ||to_char(x1.turno);
                          End If;
                       End If;
                 
                       If Nvl(x1.forma_pago, 0) <> Nvl(x2.forma_pago, 0) Then
                          If w_y = 1 Then
                             w_sql := w_sql ||', ';
                          Else
                             w_y := 1;
                          End If;
                    
                          w_sql := w_sql||' forma_pago = ';
                          If x1.forma_pago Is Null Then
                             w_sql := w_sql||' Null ';
                          Else
                             w_sql := w_sql ||to_char(x1.forma_pago);
                          End If;
                       End If;

                       If x1.sit_trabajador = 1  And
                          x2.sit_trabajador = 2 Then
                          If w_y = 1 Then
                             w_sql := w_sql ||', ';
                          Else
                             w_y := 1;
                          End If;
                    
                          w_sql := w_sql||' sit_trabajador = 1, Causa_baja = Null, Fecha_baja = Null ';
                       End If;
                 
                       If Nvl(x1.fecha_ini_contrato, Sysdate) <> Nvl(x2.fecha_ini_contrato, Sysdate) Then
                          If w_y = 1 Then
                             w_sql := w_sql ||', ';
                          Else
                             w_y := 1;
                          End If;
                    
                          w_sql := w_sql||' fecha_ini_contrato = ';
                          If x1.fecha_ini_contrato Is Null Then
                             w_sql := w_sql||' Null ';
                          Else
                             w_sql := w_sql ||w_comilla||to_char(x1.fecha_ini_contrato)||w_comilla;
                          End If;
                       End If;

                       If Nvl(x1.plazo, 0) <> Nvl(x2.plazo, 0) Then
                          If w_y = 1 Then
                             w_sql := w_sql ||', ';
                          Else
                             w_y := 1;
                          End If;
                    
                          w_sql := w_sql||' plazo = ';
                          If x1.plazo Is Null Then
                             w_sql := w_sql||' Null ';
                          Else
                             w_sql := w_sql ||to_char(x1.plazo);
                          End If;
                       End If;
                 

                       If w_y = 1 Then
                          Begin
                             w_sql := w_sql ||' Where Compania   = '||w_comilla||w_Compania  ||w_comilla||
                                              ' And   Trabajador = '||w_comilla||w_trabajador||w_comilla;
                             Execute Immediate w_sql;
                             Exception When Others Then
                                Rollback;
                                w_desc_error := 'ERRROR ACTUALIZAR REGISTRO.: '||to_char(sqlcode)||'-'||Substr(sqlerrm, 1, 150);
                                sp_alta_errores_datos_ing_WD(w_Proceso, x1.trabajador, x1.Linea, w_desc_error);
                                Update bitacora_carga_ing_WD
                                Set    Registros_error = Registros_error + 1
                                Where  Proceso = w_archivo;
                          End;
                          Commit;
                       End If;
                    End If;

                End Loop;
             End;

          End If;
       End If;

   End Loop;
   Return;
End sp_alta_trab_gral_ing_prod_dw;
/

Create Or Replace Public Synonym sp_alta_trab_gral_ing_prod_dw for sp_alta_trab_gral_ing_prod_dw;
Grant Execute on sp_alta_trab_gral_ing_prod_dw to Adama;



 