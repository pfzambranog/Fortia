Create Or Replace Procedure sp_alta_inf_complement_ING_WD
   (PsTrabajador          Char,
    PsLugar_nacimiento    Char,
    PsNacionalidad        Char,
    PsEstatura            Char,
    PsPeso                Char,
    PsColor_pelo          Char,
    PsColor_ojos          Char,
    PsTez                 Char,
    PsSenas_particulares  Char,
    PsEstado_civil        Char,
    PsCeCosto             Char  default  ' ',
    PnLinea               Number)
As

   w_trabajador             Char(10)      := Lpad(trim(PsTrabajador), 10, ' ');
   w_error                  Number(1, 0)  := 0;
   w_desc_error             Varchar2(250);
   w_proceso                Varchar2(030) := 'ARCHIVO INF_COMPLEMENTARIA.TXT';
   w_archivo                Varchar2(030) := 'INF_COMPLEMENTARIA.TXT';
   w_y                      Number(1, 0)  := 1;
   w_Estado_civil           Char(40);
   w_linea                  Number(4, 0);
   w_fecha                  Date;
   w_usuario                Varchar2(30) := User;

Begin
   w_fecha := to_date(to_char(sysdate, 'ddmmyyyyhhmiss'), 'ddmmyyyyhhmiss');

   Begin
      Select distinct 1
      Into   w_y
      From   bitacora_carga_ing_WD
      Where  Proceso = w_archivo
      And    Rownum  < 2;
      Exception When no_data_found Then
        w_y := 0;
   End;

   If w_y = 0 Then
      Insert Into bitacora_carga_ing_WD
      Select w_archivo, 1, 0, 0
      From   Dual;
   Else
      w_y := 0;
      Update bitacora_carga_ing_WD
      Set    Registros_leidos = registros_leidos + 1
      Where  Proceso = w_archivo;
   End If;

   Commit;

   w_Estado_civil := PsEstado_civil;

   If Nvl(trim(w_Estado_civil), ' ') <> ' ' Then
      Begin
         Select Estado_civil
         Into   w_Estado_civil
         From   Rel_MARITAL_STATUS_Ing_Wd
         Where  Upper(trim(Marital_status)) = Upper(trim(PsEstado_civil))
         And    Rownum                      < 2;
         Exception When no_data_found Then
            w_error      := 1;
            w_desc_error := 'SITUACION ESTADO CIVIL NO VALIDO.: '||Nvl(PsEstado_civil, ' ');
            Goto Error;
      End;

   End If;


   Begin
      Select linea
      Into   w_linea
      From   inf_complementaria_ING_WD
      Where  Trabajador = w_Trabajador
      And    Rownum < 2;
		 Exception When no_data_found Then
            w_linea := 0;
   End;

   If w_linea > 0 Then
      w_error := 1;
      w_desc_error := 'CODIGO DE TRABAJADOR PRESENTE ANTERIORMENTE EN LA LINEA '||to_char(w_linea);
	  Goto Error;
   End If;

   Begin
      Insert Into inf_complementaria_ING_WD
     (trabajador,           lugar_nacimiento,          nacionalidad,            estatura,   peso,   color_pelo,   Color_ojos, tez,
      senas_particulares,   Estado_civil,              cecosto,                 Linea)
	 Select w_Trabajador,         PsLugar_nacimiento, Upper(PsNacionalidad),   PsEstatura, PsPeso, PsColor_pelo, PsColor_ojos, PsTez,
             PsSenas_particulares, w_Estado_civil,     PsCeCosto,               PnLinea
      From   Dual;

      Update bitacora_carga_ing_WD
      Set    Registros_validos  = Registros_validos  + 1
      Where  Proceso = w_archivo;

      Exception When Others Then
         Rollback;
         w_error      := 1;
         w_desc_error := 'ERRROR AL INSERTAR REGISTRO.: '||to_char(sqlcode)||'-'||Substr(sqlerrm, 1, 150);
   End;

<<Error>>

   If w_error > 0 Then
      sp_alta_errores_datos_ing_WD(w_Proceso, Pstrabajador, PnLinea, w_desc_error);
      Update bitacora_carga_ing_WD
      Set    Registros_error = Registros_error + 1
      Where  Proceso = w_archivo;

   End If;

   Commit;
   Return;

End sp_alta_inf_complement_ING_WD;
/

Create Or Replace public Synonym sp_alta_inf_complement_ING_WD for sp_alta_inf_complement_ING_WD;
Grant Execute On sp_alta_inf_complement_ING_WD to adama;
