Create Or Replace Procedure sp_alta_errores_datos_ing_WD
      (PsProceso    Varchar,
       Pstrabajador Char,
       PnLinea      Number,
       PsError      Varchar,
       PdFecha      Date  Default sysdate)
As
   w_existe  Number(1, 0) := 0;
   
Begin

   Begin
      Select 1
      Into   w_existe
      From   errores_datos_ing_WD
      Where  Proceso    = PsProceso
	 And    Trabajador = PsTrabajador
      And    Linea      = PnLinea
      And    Rownum     < 2;
      Exception When no_data_found Then
         w_existe := 0;
   End;
   
   If w_existe = 0 Then
      Insert Into errores_datos_ing_WD
      Select PsProceso, PsTrabajador, PnLinea, Substr(PsError, 1, 250), PdFecha
      From   Dual;

      Commit;
   End If;

   Return;
End sp_alta_errores_datos_ing_WD;
/

Create Or Replace Public Synonym sp_alta_errores_datos_ing_WD for sp_alta_errores_datos_ing_WD;
Grant Execute on sp_alta_errores_datos_ing_WD to adama;

