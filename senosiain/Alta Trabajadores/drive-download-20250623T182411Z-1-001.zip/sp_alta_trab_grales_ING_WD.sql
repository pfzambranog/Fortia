Create Or Replace Procedure sp_alta_trab_grales_ING_WD
 ( PsCompania               Char,
   PsTrabajador             Char,
   PsFecha_ingreso          Char,
   PsFecha_antiguedad       Char,
   PsFecha_vto_contrato     Char,
   PsRelacion_laboral       Char,
   PsTelefono_oficina       Varchar2,
   PnExtension_telefonica   Number,
   PsClase_nomina           Char,
   PnSistema_antiguedad     Number,
   Pnsistema_horario        Number,
   Pnturno                  Number,
   Pnforma_pago             Number,
   Pnsit_trabajador         Number,
   Psfecha_ini_contrato     Char,
   PnPlazo                  Number,
   PnAship                  Number,
   PsPuesto                 Char,
   PsIdSupervisor           Char,
   PsInstitucion_Deposito   Char,
   PsCuenta_deposito        Char,
   PnVariable52             Number    Default 0,
   PnVariable53             Number    Default 0,
   PnLinea                  Number)
As

   w_trabajador             Char(10)      := Lpad(trim(PsTrabajador),   10, ' ');
   w_IdSupervisor           Char(10)      := Lpad(trim(PsIdSupervisor), 10, ' ');
   w_error                  Number(1, 0)  := 0;
   w_nuevo                  Number(1, 0)  := 0;
   w_desc_error             Varchar2(250);
   w_proceso                Varchar2(040) := 'ARCHIV TRABAJADORES_GRALES.TXT';
   w_archivo                Varchar2(040) := 'TRABAJADORES_GRALES.TXT';
   w_len                    Number(3, 0)  := 0;
   w_x                      Number(3, 0)  := 1;
   w_y                      Number(1, 0)  := 0;
   w_linea                  Number(4, 0)  := 0;
   w_plazo                  Number(4, 0)  := 0;
   w_Fecha_ingreso          Date;
   w_Fecha_antiguedad       Date;
   w_Fecha_vto_contrato     Date;
   w_fecha_ini_contrato     Date;
   w_cambio_puesto          Char(2);
   w_compania               Char(4);

Begin
   Begin
      Select distinct 1
      Into   w_y
      From   bitacora_carga_ing_WD
      Where  Proceso = w_archivo
      And    Rownum  < 2;
      Exception When no_data_found Then
        w_y := 0;
   End;

   If w_y = 0 Then
      Insert Into bitacora_carga_ing_WD
      Select w_archivo, 1, 0, 0
      From   Dual;
   Else
      w_y := 0;
      Update bitacora_carga_ing_WD
      Set    Registros_leidos = registros_leidos + 1
      Where  Proceso = w_archivo;
   End If;

   Commit;

   If Nvl(Pnsit_trabajador, 0) Not in (1, 2) Then
      w_error      := 1;
      w_desc_error := 'SITUACION DE TRABAJADOR NO VALIDO';
      Goto Error;
   End If;

   If Nvl(Pnforma_pago, 0) Not in (1, 2, 3) Then
      w_error      := 1;
      w_desc_error := 'FORMA DE PAGO DEL TRABAJADOR NO VALIDO';
      Goto Error;
   End If;

   Begin
      Select to_date(Psfecha_ingreso, 'dd/mm/yyyy')
      Into   w_fecha_ingreso
      From   dual;
      Exception when Others Then
         w_error      := 1;
         w_desc_error := 'FORMATO DE FECHA DE INGRESO NO VALIDO';
         Goto Error;
   End;

   Begin
      Select to_date(Psfecha_Antiguedad, 'dd/mm/yyyy')
      Into   w_fecha_Antiguedad
      From   dual;
      Exception when Others Then
         w_error      := 1;
         w_desc_error := 'FORMATO DE FECHA DE ANTIGUEDAD NO VALIDO';
         Goto Error;
   End;

   If w_fecha_ingreso < w_fecha_Antiguedad Then
      w_error      := 1;
      w_desc_error := 'FECHA DE INGRESO < FECHA DE ANTIGUEDAD';
      Goto Error;
   End If;

   Begin
      Select vigencia
      Into   w_y
      From   Relaciones_laborales
      Where  Relacion_laboral = PsRelacion_laboral
      And    Rownum           < 2;
      Exception When no_data_found Then
         w_error      := 1;
         w_desc_error := 'CODIGO DE RELACION LABORAL NO VALIDO.: ' ||Nvl(PsRelacion_laboral, ' ' );
         Goto Error;
   End;

   If w_y = 1   Then
      Begin
         Select to_date(Psfecha_ini_contrato, 'dd/mm/yyyy')
         Into   w_fecha_ini_contrato
         From   dual;
         Exception when Others Then
            w_error      := 1;
            w_desc_error := 'FORMATO DE FECHA DE INICIO CONTRATO NO VALIDO';
           Goto Error;
      End;

      Begin
         Select to_date(Psfecha_vto_contrato, 'dd/mm/yyyy')
         Into   w_fecha_vto_contrato
         From   dual;
         Exception when Others Then
            w_error      := 1;
            w_desc_error := 'FORMATO DE FECHA DE VENCIMIENTO CONTRATO NO VALIDO';
           Goto Error;
      End;

      If Nvl(PnPlazo, 0) > 0 Then
         w_plazo := PnPlazo;
      Else
         w_plazo := w_fecha_vto_contrato - w_fecha_ini_contrato + 1;
      End If;
   End If;

   Begin
      Select 1
      Into   w_y
      From   Companias
      Where  Compania = PsCompania
      And    Rownum   < 2;
      Exception When no_data_found Then
         w_error      := 1;
         w_desc_error := 'CODIGO DE COMPANIA NO VALIDO.: ' ||Nvl(PsCompania, ' ' );
         Goto Error;
   End;

   Begin
      Select 1
      Into   w_y
      From   Clases_nomina
      Where  Clase_nomina = PsClase_nomina
      And    Rownum       < 2;
      Exception When no_data_found Then
         w_error      := 1;
         w_desc_error := 'CODIGO DE CLASE DE NOMINA NO VALIDO.: ' ||Nvl(PsClase_nomina, ' ' );
         Goto Error;
   End;

   Begin
      Select Distinct 1
      Into   w_y
      From   sistemas_antiguedad
      Where  sistema_antiguedad = Pnsistema_antiguedad
      And    Rownum             < 2;
      Exception When no_data_found Then
         w_error      := 1;
         w_desc_error := 'CODIGO DE SISTEMA ANTIGUEDAD NO VALIDO.: ' ||Nvl(to_char(Pnsistema_antiguedad), ' ' );
         Goto Error;
   End;

   Begin
      Select Distinct 1
      Into   w_y
      From   sistemas_horario
      Where  sistema_horario = PnSistema_Horario
      And    Rownum          < 2;
      Exception When no_data_found Then
         w_error      := 1;
         w_desc_error := 'CODIGO DE SISTEMA HORARIO NO VALIDO.: ' ||Nvl(to_char(PnSistema_Horario), ' ' );
         Goto Error;
   End;

   Begin
      Select Distinct 1
      Into   w_y
      From   Turnos
      Where  turno    = Pnturno
      And    Rownum   < 2;
      Exception When no_data_found Then
         w_error      := 1;
         w_desc_error := 'CODIGO DE TURNO NO VALIDO.: ' ||Nvl(to_char(PnTurno), ' ' );
         Goto Error;
   End;

   Begin
      Select linea
      Into   w_linea
      From   trabajadores_grales_ING_WD
      Where  Compania    = PsCompania
      And    Trabajador  = w_Trabajador
      And    Rownum      < 2;
      Exception When no_data_found Then
         w_linea := 0;
   End;

   If w_linea > 0 Then
      w_error := 1;
      w_desc_error := 'CODIGO DE TRABAJADOR PRESENTE ANTERIORMENTE EN LA L�NEA '||to_char(w_linea);
      Goto Error;
   End If;

   If nvl(trim(PsPuesto), '') <> '' Then
      Begin
         Select Distinct 1
         Into   w_y
         From   puestos
         Where  puesto = PsPuesto
         And    Rownum < 2;
         Exception When no_data_found Then
            w_error      := 1;
            w_desc_error := 'CODIGO DE PUESTO NO VALIDO.: ' ||Nvl(PsPuesto, ' ' );
            Goto Error;
      End;

      If w_y = 1 Then
         w_cambio_puesto := '03';
      Else
         w_cambio_puesto := '01';
      End If;

   End If;

/*
   Begin
      Select Distinct 1
      Into   w_y
      From   Ins_Depositos
      Where  Institucion_Deposito = PsInstitucion_Deposito
      And    Rownum               < 2;
         Exception When no_data_found Then
            w_error      := 1;
            w_desc_error := 'CODIGO DE ENTIDAD FINANCIERA DE PAGO NO VALIDO.: ' ||Nvl(PsInstitucion_Deposito, ' ' );
            Goto Error;
   End;

*/

   Begin
      Select 1
      Into   w_nuevo
      From   trabajadores_grales
      Where  Compania   = PsCompania
      And    Trabajador = w_Trabajador
      And    Rownum     < 2;
      Exception when no_data_found Then
         w_nuevo := 0;

   End;

   Begin
      Insert Into trabajadores_grales_ING_WD
             (compania,           trabajador,             fecha_ingreso,          fecha_antiguedad,     fecha_vto_contrato,   relacion_laboral,
              telefono_oficina,   extension_telefonica,   clase_nomina,           sistema_antiguedad,   sistema_horario,      turno,
              forma_pago,         sit_trabajador,         fecha_ini_contrato,     plazo,                aship,                puesto,
              causa_cambio,       idsupervisor,           institucion_deposito,   cuenta_deposito,      variable52,           variable53,
              linea)
      Values (Pscompania,         w_trabajador,           w_fecha_ingreso,        w_fecha_antiguedad,   w_fecha_vto_contrato, PsRelacion_laboral,
              Pstelefono_oficina, Pnextension_telefonica, Psclase_nomina,         Pnsistema_antiguedad, Pnsistema_horario,    Pnturno,
              Pnforma_pago,       Pnsit_trabajador,       w_fecha_ini_contrato,   w_plazo,              PnAship,              PsPuesto,
              w_cambio_puesto,    w_IdSupervisor,         PsInstitucion_Deposito, psCuenta_deposito,    PnVariable52,         PnVariable53,
              PnLinea);
      w_x := 0;

      Update bitacora_carga_ing_WD
      Set    Registros_validos  = Registros_validos  + 1
      Where  Proceso = w_archivo;
      Commit;

      Exception When Others Then
         Rollback;
         w_error      := 1;
         w_desc_error := 'ERRROR AL INSERTAR REGISTRO.: '||to_char(sqlcode)||'-'||Substr(sqlerrm, 1, 150);
   End;

<<Error>>

   If w_error > 0 Then
      sp_alta_errores_datos_ing_WD(w_Proceso, Pstrabajador, PnLinea, w_desc_error);
      Update bitacora_carga_ing_WD
      Set    Registros_error = Registros_error + 1
      Where  Proceso = w_archivo;

   Else
      If w_x = 0 And w_nuevo = 0 Then
         Begin
            Select Compania
            Into   w_compania
            From   trabajadores_nuevos_ING_WD
            Where  Trabajador = PsTrabajador
            And    Rownum     < 2;
            Exception When no_data_found Then
               w_x := 1;
               Insert Into trabajadores_nuevos_ING_WD
               Values (PsCompania, PsTrabajador, ' ');
          End;

          If w_x         = 0           And
             w_compania <> PsCompania Then
             Update trabajadores_nuevos_ING_WD
             Set    Compania   = PsCompania
             Where  Trabajador = w_Trabajador
             And    Rownum     < 2;
          End If;
      End If;

   End If;
   Commit;
   Return;

End sp_alta_trab_grales_ING_WD;
/

Create Or Replace Public Synonym sp_alta_trab_grales_ING_WD for sp_alta_trab_grales_ING_WD;
Grant Execute on sp_alta_trab_grales_ING_WD to Adama;

