Create or Replace Procedure sp_alta_rel_tra_agr_ing_pro_wd

As
   w_error                  Number(1, 0)  := 0;
   w_desc_error             Varchar2(250);
   w_proceso                Varchar2(040) := 'ARCHIVO AGRUPACIONES.TXT';
   w_archivo                Varchar2(040) := 'AGRUPACIONES.TXT';
   w_y                      Number(1, 0)  := 1;
   w_linea                  Number(4, 0);
   w_secuencia              Number(4, 0);
   w_compania               Char( 4);
   w_dato                   Char(10);

   Cursor C_trab_new Is
   Select *
   From   rel_trab_agr_ING_DW 
   Order  by Linea;

Begin

   For X1 in C_trab_new Loop
       Begin
          Select Distinct 0
          Into   w_error
          From   Trabajadores_grales
          Where  Compania   = x1.compania
          And    Trabajador = x1.trabajador
          And    Rownum      < 2;
          Exception When no_data_Found Then
             w_error := 1;
             w_desc_error := 'CODIGO DE TRABAJADOR NO EXISTE EN TRABAJADORES_GRALES.';
             sp_alta_errores_datos_ing_WD(w_Proceso, x1.trabajador, x1.Linea, w_desc_error);
             Update bitacora_carga_ing_WD
             Set    Registros_error = Registros_error + 1
             Where  Proceso = w_archivo;
             Commit;
       End;

       If w_error = 0 Then   

          Begin
             w_y    := 0;
             w_dato := ' ';

             Select dato
             Into   w_dato
             From   rel_trab_agr
             Where  Compania   = x1.compania
             And    Trabajador = x1.trabajador
             And    Agrupacion = x1.agrupacion;
             Exception When no_data_found Then
                w_y    := 1;
                w_dato := ' ';
          End;
                    
          If w_dato <> x1.dato  Then
             Begin
                w_error := 0;
                sp_alta_rel_trab_agr(x1.compania, x1.trabajador, x1.agrupacion, x1.dato);
                Exception When Others Then
                   Rollback;
                   w_error      := 1;
                   w_desc_error := 'ERRROR AL INSERTAR REGISTRO.: '||to_char(sqlcode)||'-'||Substr(sqlerrm, 1, 150);
                   sp_alta_errores_datos_ing_WD(w_Proceso, x1.trabajador, x1.Linea, w_desc_error);
                   Update bitacora_carga_ing_WD
                   Set    Registros_error = Registros_error + 1
                   Where  Proceso = w_archivo;
             End;
             Commit;

             If w_error = 0 Then
                sp_gen_stat_ha_trab (x1.compania, x1.trabajador);
             End If;
          End If;
       End If;
   End Loop;
   Commit;
   Return;

End sp_alta_rel_tra_agr_ing_pro_wd;
/


Create Or Replace public Synonym sp_alta_rel_tra_agr_ing_pro_wd for sp_alta_rel_tra_agr_ing_pro_wd;
Grant Execute On sp_alta_rel_tra_agr_ing_pro_wd to adama;