Create Or Replace Procedure sp_alta_trab_ing_prod_dw
As

   w_trabajador     Char(10);
   w_x              Number(1, 0);
   w_y              Number(1, 0);
   w_sql            Varchar2(4000);
   w_comilla        Char(1) := Chr(39);
   w_desc_error     Varchar2(250);
   w_proceso        Varchar2(030) := 'ARCHIVO TRABAJADORES.TXT';
   w_archivo        Varchar2(030) := 'TRABAJADORES.TXT';
 
   Cursor C_trab_new Is
   Select *
   From   trabajadores_ING_WD
   Order  by Linea;
   
   Cursor C_trabajadores Is
   Select *
   From   trabajadores
   Where  Trabajador = w_trabajador;

Begin

   For X1 in C_trab_new Loop
       w_trabajador := x1.trabajador;
       
       Begin
          Select Distinct 1
          Into   w_x
          From   Trabajadores
          Where  Trabajador = w_trabajador
          And    Rownum      < 2;
          Exception When no_data_Found Then
             w_x := 0;
       End;
       
       If w_x = 0 Then
          Begin
             Insert Into Trabajadores 
             Select x1.trabajador,        x1.registro_fiscal, x1.nombre,          x1.nombre_abreviado,    x1.sexo,
                    x1.fecha_nacimiento,  X1.domicilio,       x1.domicilio2,      x1.poblacion,           x1.estado_provincia,
                    x1.pais,              x1.codigo_postal,   x1.calles_aledanas, x1.telefono_particular, x1.reg_seguro_social,
                    x1.domicilio3,        x1.clave_unica,     x1.e_mail
             From   Dual;
             Exception When Others Then
                Rollback;
                w_desc_error := 'ERRROR AL INSERTAR REGISTRO.: '||to_char(sqlcode)||'-'||Substr(sqlerrm, 1, 150);
                sp_alta_errores_datos_ing_WD(w_Proceso, x1.trabajador, x1.Linea, w_desc_error);
                Update bitacora_carga_ing_WD
                Set    Registros_error = Registros_error + 1
                Where  Proceso = w_archivo;

          End;
          Commit;
       Else
          Begin
             For X2 In C_Trabajadores Loop
                 w_sql := 'Update Trabajadores ' ||
                          'Set    ';
                 w_y := 0;
                 
                 If Nvl(x1.registro_fiscal, ' ') <> Nvl(x2.registro_fiscal, ' ') Then
                    w_y := 1;
                    w_sql := w_sql||' registro_fiscal = ';
                    If x1.registro_fiscal Is  Null Then
                       w_sql := w_sql||' Null ';
                    Else 
                       w_sql := w_sql||w_comilla||trim(x1.registro_fiscal)||w_comilla;
                    End If;
                 End If;
                 
                 If Nvl(x1.nombre, ' ') <> Nvl(x2.nombre, ' ') Then
                    If w_y = 1 Then
                       w_sql := w_sql ||', ';
                    Else
                       w_y := 1;
                    End If;
                    
                    w_sql := w_sql||' nombre = ';
                    If x1.nombre Is Null Then
                       w_sql := w_sql||' Null ';
                    Else
                       w_sql := w_sql ||w_comilla||trim(x1.nombre)||w_comilla;
                    End If;
                 End If;
                 
                 If Nvl(x1.nombre_abreviado, ' ') <> Nvl(x2.nombre_abreviado, ' ') Then
                    If w_y = 1 Then
                       w_sql := w_sql ||', ';
                    Else
                       w_y := 1;
                    End If;
                    
                    w_sql := w_sql||' nombre_abreviado = ';
                    If x1.nombre_abreviado is Null Then
                       w_sql := w_sql ||' Null ';
                    Else
                       w_sql := w_sql || w_comilla||trim(x1.nombre_abreviado)||w_comilla;
                    End If;
                 End If;
                 
                 If Nvl(x1.sexo, 0) <> Nvl(x2.sexo, 0) Then
                    If w_y = 1 Then
                       w_sql := w_sql ||', ';
                    Else
                       w_y := 1;
                    End If;
                    
                    w_sql := w_sql||' sexo = ';
                    If x1.sexo Is Null Then
                       w_sql := w_sql ||' Null ';
                    Else
                       w_sql := w_sql ||to_char(x1.sexo);
                    End If;
                 End If;

                 If Nvl(x1.fecha_nacimiento, Sysdate) <> Nvl(x2.fecha_nacimiento, Sysdate) Then
                    If w_y = 1 Then
                       w_sql := w_sql ||', ';
                    Else
                       w_y := 1;
                    End If;
                    
                    w_sql := w_sql||' fecha_nacimiento = ';
                    If x1.fecha_nacimiento Is Null Then
                       w_sql := w_sql ||' Null ';
                    Else
                       w_sql := w_sql ||w_comilla||to_char(x1.fecha_nacimiento)||w_comilla;
                    End If;
                 End If;

                 If Nvl(x1.domicilio, ' ') <> Nvl(x2.domicilio, ' ') Then
                    If w_y = 1 Then
                       w_sql := w_sql ||', ';
                    Else
                       w_y := 1;
                    End If;
                    
                    w_sql := w_sql||' domicilio = ';
                    
                    If x1.domicilio is Null Then
                       w_sql := w_sql ||' Null ';
                    Else
                       w_sql := w_sql ||w_comilla||trim(x1.domicilio)||w_comilla;
                    End If;
                 End If;

                 If Nvl(x1.domicilio2, ' ') <> Nvl(x2.domicilio2, ' ') Then
                    If w_y = 1 Then
                       w_sql := w_sql ||', ';
                    Else
                       w_y := 1;
                    End If;
                    
                    w_sql := w_sql||' domicilio2 = ';
                    If x1.domicilio2 Is Null Then
                       w_sql := w_sql ||' Null ';
                    Else
                       w_sql := w_sql ||w_comilla||trim(x1.domicilio2)||w_comilla;
                    End If;
                 End If;

                 If Nvl(x1.poblacion, ' ') <> Nvl(x2.poblacion, ' ') Then
                    If w_y = 1 Then
                       w_sql := w_sql ||', ';
                    Else
                       w_y := 1;
                    End If;
                    
                    w_sql := w_sql||' poblacion = ';
                    If x1.poblacion Is Null Then
                       w_sql := w_sql ||' Null ';
                    Else
                       w_sql := w_sql ||w_comilla||trim(x1.poblacion)||w_comilla;
                    End If;
                 End If;
                 
                 If Nvl(x1.estado_provincia, ' ') <> Nvl(x2.estado_provincia, ' ') Then
                    If w_y = 1 Then
                       w_sql := w_sql ||', ';
                    Else
                       w_y := 1;
                    End If;
                    
                    w_sql := w_sql||' estado_provincia = ';
                    If x1.estado_provincia Is Null Then
                       w_sql := w_sql ||' Null ';
                    Else
                       w_sql := w_sql ||w_comilla||trim(x1.estado_provincia)||w_comilla;
                    End If;
                 End If;

                 If Nvl(x1.pais, ' ') <> Nvl(x2.pais, ' ') Then
                    If w_y = 1 Then
                       w_sql := w_sql ||', ';
                    Else
                       w_y := 1;
                    End If;
                    
                    w_sql := w_sql||' pais = ';
                    If x1.pais Is Null Then
                        w_sql := w_sql ||' Null ';
                    Else
                       w_sql := w_sql ||w_comilla||trim(x1.pais)||w_comilla;
                    End If;
                 End If;

                 If Nvl(x1.codigo_postal, ' ') <> Nvl(x2.codigo_postal, ' ') Then
                    If w_y = 1 Then
                       w_sql := w_sql ||', ';
                    Else
                       w_y := 1;
                    End If;
                    
                    w_sql := w_sql||' codigo_postal = ';
                    If x1.codigo_postal Is Null Then
                        w_sql := w_sql ||' Null ';
                    Else
                       w_sql := w_sql ||w_comilla||trim(x1.codigo_postal)||w_comilla;
                    End If;
                 End If;

                 If Nvl(x1.calles_aledanas, ' ') <> Nvl(x2.calles_aledanas, ' ') Then
                    If w_y = 1 Then
                       w_sql := w_sql ||', ';
                    Else
                       w_y := 1;
                    End If;
                    
                    w_sql := w_sql||' calles_aledanas = ';
                    If trim(x1.calles_aledanas) Is Null Then
                      w_sql := w_sql ||' Null ';
                    Else
                       w_sql := w_sql ||w_comilla||trim(x1.calles_aledanas)||w_comilla;
                    End If;
                 End If;
                 
                 If Nvl(x1.telefono_particular, ' ') <> Nvl(x2.telefono_particular, ' ') Then
                    If w_y = 1 Then
                       w_sql := w_sql ||', ';
                    Else
                       w_y := 1;
                    End If;
                    
                    w_sql := w_sql||' telefono_particular = ';
                    If x1.telefono_particular Is Null Then
                       w_sql := w_sql ||' Null ';
                    Else
                       w_sql := w_sql ||w_comilla||trim(x1.telefono_particular)||w_comilla;
                    End If;
                 End If;
                 
                 If Nvl(x1.reg_seguro_social, ' ') <> Nvl(x2.reg_seguro_social, ' ') Then
                    If w_y = 1 Then
                       w_sql := w_sql ||', ';
                    Else
                       w_y := 1;
                    End If;
                    
                    w_sql := w_sql||' reg_seguro_social = ';
                    If x1.reg_seguro_social Is Null Then
                        w_sql := w_sql ||' Null ';
                    Else
                       w_sql := w_sql ||w_comilla||trim(x1.reg_seguro_social)||w_comilla;
                    End If;
                 End If;

                 If Nvl(x1.domicilio3, ' ') <> Nvl(x2.domicilio3, ' ') Then
                    If w_y = 1 Then
                       w_sql := w_sql ||', ';
                    Else
                       w_y := 1;
                    End If;
                    
                    w_sql := w_sql||' domicilio3 = ';
                    If x1.domicilio3 Is Null Then
                       w_sql := w_sql ||' Null ';
                    Else
                       w_sql := w_sql ||w_comilla||trim(x1.domicilio3)||w_comilla;
                    End If;
                 End If;
                 
                 If Nvl(x1.clave_unica, ' ') <> Nvl(x2.clave_unica, ' ') Then
                    If w_y = 1 Then
                       w_sql := w_sql ||', ';
                    Else
                       w_y := 1;
                    End If;
                    
                    w_sql := w_sql||' clave_unica = ';
                    If x1.clave_unica Is Null Then
                       w_sql := w_sql ||' Null ';
                    Else
                       w_sql := w_sql ||w_comilla||trim(x1.clave_unica)||w_comilla;
                    End If;
                 End If;
                 
                 If nvl(x1.e_mail, ' ') <> Nvl(x2.e_mail, ' ') Then
                    If w_y = 1 Then
                       w_sql := w_sql ||', ';
                    Else
                       w_y := 1;
                    End If;
                    
                    w_sql := w_sql||' e_mail = ';
                    If x1.e_mail Is Null Then
                       w_sql := w_sql ||' Null ';
                    Else
                       w_sql := w_sql ||w_comilla||trim(x1.e_mail)||w_comilla;
                    End If;
                    
                 End If;

                 w_sql := w_sql ||' Where Trabajador = '||w_comilla||w_trabajador||w_comilla;
                 
                 If w_y = 1 Then
                    Begin
                       Execute Immediate w_sql;
                       Exception When Others Then
                          Rollback;
                          w_desc_error := 'ERRROR AL INSERTAR REGISTRO.: '||to_char(sqlcode)||'-'||Substr(sqlerrm, 1, 150);
                          sp_alta_errores_datos_ing_WD(w_Proceso, x1.trabajador, x1.Linea, w_desc_error);
                          Update bitacora_carga_ing_WD
                          Set    Registros_error = Registros_error + 1
                          Where  Proceso = w_archivo;
                    End;
                    Commit;
                 End If;
             End Loop;
          End;
      End If;
   End Loop;
   Return;

 End sp_alta_trab_ing_prod_dw;
 /
 
Create Or Replace Public Synonym sp_alta_trab_ing_prod_dw for sp_alta_trab_ing_prod_dw;
Grant Execute on sp_alta_trab_ing_prod_dw to Adama;
