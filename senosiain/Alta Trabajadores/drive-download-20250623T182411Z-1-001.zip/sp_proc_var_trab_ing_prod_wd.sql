Create or Replace Procedure sp_proc_var_trab_ing_prod_wd
As
   w_error                  Number(1, 0)  := 0;
   w_desc_error             Varchar2(250);
   w_proceso                Varchar2(030) := 'VARIABLES TRABAJADOR';
   w_sql                    Varchar2(4000);
   w_y                      Number(1, 0)  := 1;
   w_linea                  Number(4, 0);
   w_comilla                Char(1) := Chr(39);
   w_aship                  number(19, 6);

   Cursor C_trab_new Is
   Select Compania, Trabajador, Aship, Linea 
   From   trabajadores_grales_ING_WD
   Where  Nvl(Aship, 0) != 0   
   Order  by Linea;

Begin

   For X1 in C_trab_new Loop
       Begin
          Select Distinct 1
          Into   w_error
          From   bitacora_carga_ing_WD
          Where  Proceso = w_proceso
          And    Rownum  < 2;
          Exception When no_data_found Then
             Insert into bitacora_carga_ing_WD
             Values (w_proceso, 0, 0, 0);
       End;

       Update bitacora_carga_ing_WD
       Set    Registros_leidos = Registros_leidos + 1
       Where  Proceso = w_proceso;
       Commit;

       Begin
          Select Distinct 0
          Into   w_error
          From   Trabajadores_grales
          Where  Compania   = x1.compania
          And    Trabajador = x1.trabajador
          And    Rownum      < 2;
          Exception When no_data_Found Then
             w_error := 1;
             w_desc_error := 'CODIGO DE TRABAJADOR NO EXISTE EN TRABAJADORES_GRALES.';
             sp_alta_errores_datos_ing_WD(w_Proceso, x1.trabajador, x1.Linea, w_desc_error);
             Update bitacora_carga_ing_WD
             Set    Registros_error = Registros_error + 1
             Where  Proceso = w_proceso;
             Commit;

       End;

       If w_error = 0 Then
          Begin
             w_y := 0;
             Select Variable_trabajador
             Into   w_aship
             From   Variables_trabajador
             Where  Compania   = x1.Compania
             And    Trabajador = x1.trabajador
             And    Secuencia  = 75
             And    Rownum     < 2;
             Exception When no_data_found Then
                w_y := 1;
         End;
         
         If w_y = 1 Then
            Begin
               Sp_alta_variables_trabajador (x1.compania, x1.trabajador, 75, x1.aship);
               Exception When Others Then
                  Rollback;
                  w_desc_error := 'ERRROR AL INSERTAR REGISTRO.: '||to_char(sqlcode)||'-'||Substr(sqlerrm, 1, 150);
                  sp_alta_errores_datos_ing_WD(w_Proceso, x1.trabajador, x1.Linea, w_desc_error);
                  Update bitacora_carga_ing_WD
                  Set    Registros_error = Registros_error + 1
                  Where  Proceso = w_proceso;
                  Commit;

            End;
         ElsIf nvl(w_aship, 0) <> x1.aship Then
            Begin
               Sp_cambio_variables_trabajador (x1.compania, x1.trabajador, 75, x1.aship);
               Exception When Others Then
                  Rollback;
                  w_desc_error := 'ERRROR AL Cambiar REGISTRO.: '||to_char(sqlcode)||'-'||Substr(sqlerrm, 1, 150);
                  sp_alta_errores_datos_ing_WD(w_Proceso, x1.trabajador, x1.Linea, w_desc_error);
                  Update bitacora_carga_ing_WD
                  Set    Registros_error = Registros_error + 1
                  Where  Proceso = w_proceso;
                  Commit;
            End;
         
         End If;
         Commit;

       End If;
   End Loop;
   Commit;
   Return;

End sp_proc_var_trab_ing_prod_wd;
/

Create Or Replace Public Synonym sp_proc_var_trab_ing_prod_wd for sp_proc_var_trab_ing_prod_wd;
Grant  Execute on sp_proc_var_trab_ing_prod_wd to Adama;

