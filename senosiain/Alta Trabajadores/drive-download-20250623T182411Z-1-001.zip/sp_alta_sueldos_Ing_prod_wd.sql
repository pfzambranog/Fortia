Create Or Replace Procedure sp_alta_sueldos_Ing_prod_wd

As
   w_error                  Number(1, 0)  := 0;
   w_desc_error             Varchar2(250);
   w_proceso                Varchar2(030) := 'ARCHIVO SUELDO.TXT';
   w_archivo                Varchar2(030) := 'SUELDO.TXT';
   w_salario                Number(15, 6);
   w_salario_act            Number(15, 6);
   w_secuencia              Integer;
   w_causa_aumento          Char(2);
   w_fecha_ingreso          Date;
 
   Cursor C_trab_new Is
   Select *
   From   sueldos_ING_WD
   Order  by Linea;

Begin

   For X1 in C_trab_new Loop
       w_causa_aumento := x1.causa_aumento;

       Begin
          Select 0,          fecha_ingreso
          Into   w_error,    w_fecha_ingreso
          From   Trabajadores_grales
          Where  Compania   = X1.compania
          And    Trabajador = x1.trabajador
          And    Rownum      < 2;
          Exception When no_data_Found Then
             w_error := 1;
             w_desc_error := 'CODIGO DE TRABAJADOR NO EXISTE EN TRABAJADORES_GRALES.';
             sp_alta_errores_datos_ing_WD(w_Proceso, x1.trabajador, x1.Linea, w_desc_error);
             Update bitacora_carga_ing_WD
             Set    Registros_error = Registros_error + 1
             Where  Proceso = w_archivo;
             Commit;
       End;

       If w_fecha_ingreso = x1.fecha Then
           w_causa_aumento := 'IN';
       End If;

       If w_error = 0 Then
          w_secuencia := 0;
          Begin
             Select Salario
             Into   w_salario
             From   Historico_sueldos a
             Where  Compania   = x1.Compania
             And    Trabajador = x1.Trabajador
             And    Fecha      = x1.fecha
             And    Secuencia  = (Select Max(secuencia)
                                  From   Historico_sueldos
                                  Where  Compania   = a.Compania
                                  And    Trabajador = a.Trabajador
                                  And    Fecha      = a.fecha);
             Exception When no_data_found Then
                w_salario   := 0;
                w_secuencia := 1;
          End;
              
          w_salario_act := x1.salario / 30;
          If trunc(w_salario) <> trunc(w_salario_act) Then
             Begin
                sp_alta_historico_sueldos(x1.compania, x1.trabajador, w_secuencia, x1.fecha, w_salario_act, Null, Null, Null, Null, w_causa_aumento,
                                          x1.grupo_salario, 0);
                Exception When Others Then
                   Rollback;
                   w_desc_error := 'ERRROR AL INSERTAR REGISTRO.: '||to_char(sqlcode)||'-'||Substr(sqlerrm, 1, 150);
                   sp_alta_errores_datos_ing_WD(w_Proceso, x1.trabajador, x1.Linea, w_desc_error);
                   Update bitacora_carga_ing_WD
                   Set    Registros_error = Registros_error + 1
                   Where  Proceso = w_archivo;
             End;
             Commit;
          End If;
       End If;
   End Loop;
   Commit;
   Return;

End sp_alta_sueldos_Ing_prod_wd;
/

Create Or Replace Public Synonym sp_alta_sueldos_Ing_prod_wd for sp_alta_sueldos_Ing_prod_wd;
Grant Execute on sp_alta_sueldos_Ing_prod_wd to Adama;