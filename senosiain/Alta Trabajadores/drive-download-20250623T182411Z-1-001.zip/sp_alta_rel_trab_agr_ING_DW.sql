Create or Replace Procedure sp_alta_rel_trab_agr_ING_DW
   (PsCompania        Char,
    PsTrabajador      Char,
    PsAgrupacion      Char,
    PsDato            Char,
    PnLinea           Number)
As
   w_trabajador             Char(10)      := Lpad(trim(PsTrabajador), 10, ' ');
   w_error                  Number(1, 0)  := 0;
   w_desc_error             Varchar2(250);
   w_proceso                Varchar2(030) := 'ARCHIVO AGRUPACIONES.TXT';
   w_archivo                Varchar2(030) := 'AGRUPACIONES.TXT';
   w_y                      Number(1, 0)  := 1;
   w_linea                  Number(4, 0);
   w_secuencia              Number(4, 0);
   w_fecha                  Date;

Begin
   Begin
      Select distinct 1
      Into   w_y
      From   bitacora_carga_ing_WD
      Where  Proceso = w_archivo
      And    Rownum  < 2;
      Exception When no_data_found Then
        w_y := 0;
   End;
   
   If w_y = 0 Then
      Insert Into bitacora_carga_ing_WD
      Select w_archivo, 1, 0, 0
      From   Dual;
   Else
      w_y := 0;
      Update bitacora_carga_ing_WD
      Set    Registros_leidos = registros_leidos + 1
      Where  Proceso = w_archivo;
   End If;

   Commit;
   
   Begin
      Select 1
      Into   w_y
      From   Companias
      Where  Compania = PsCompania
      And    Rownum   < 2;
      Exception When no_data_found Then
         w_error      := 1;
         w_desc_error := 'CODIGO DE COMPANIA NO VALIDO.: ' ||Nvl(PsCompania, ' ' );
         Goto Error;
   End;
   
   Begin
      Select 1
      Into   w_y
      From   Agrupaciones_trab
      Where  Agrupacion = PsAgrupacion
      And    Rownum   < 2;
      Exception When no_data_found Then
         w_error      := 1;
         w_desc_error := 'CODIGO DE AGRUPACION DE TRABAJADOR NO VALIDO.: ' ||Nvl(PsAgrupacion, ' ' );
         Goto Error;
   End;

   Begin
      Select 1
      Into   w_y
      From   Rel_Agr_Companias
      Where  Compania   = PsCompania
	  And    Agrupacion = PsAgrupacion
      And    Rownum     < 2;
      Exception When no_data_found Then
         w_error      := 1;
         w_desc_error := 'CODIGO DE AGRUPACION DE TRABAJADOR NO RELACIONADO A LA COMPANIA.: ' ||Nvl(PsCompania, ' ' )||' - '||Nvl(PsAgrupacion, ' ' );
         Goto Error;
   End;

   Begin
      Select 1
      Into   w_y
      From   datos_agr_trab
      Where  Agrupacion = PsAgrupacion
	  And    Dato       = PsDato
      And    Rownum     < 2;
      Exception When no_data_found Then
         w_error      := 1;
         w_desc_error := 'CODIGO DE DATO DE AGRUPACION DE TRABAJADOR NO VALIDO.: ' ||Nvl(PsAgrupacion, ' ' )||' - '||Nvl(PsDato, ' ' );
         Goto Error;
   End;

   Begin
      Select linea
      Into   w_linea
      From   rel_trab_agr_ING_DW
      Where  Compania   = PsCompania
      And    Trabajador = w_Trabajador
      And    Agrupacion = PsAgrupacion
      And    Rownum     < 2;
      Exception When no_data_found Then
            w_linea := 0;
   End;
   
   If w_linea > 0 Then
      w_error := 1;
      w_desc_error := 'CODIGO DE TRABAJADOR PRESENTE ANTERIORMENTE EN LA LINEA '||to_char(w_linea);
      Goto Error;
   End If;
   
   Begin
      Insert Into rel_trab_agr_ING_DW
      Select PsCompania, w_Trabajador, PsAgrupacion, PsDato, PnLinea
      From   Dual;
      
      Update bitacora_carga_ing_WD
      Set    Registros_validos  = Registros_validos  + 1
      Where  Proceso = w_archivo;

      Exception When Others Then
         Rollback;
         w_error      := 1;
         w_desc_error := 'ERRROR AL INSERTAR REGISTRO.: '||to_char(sqlcode)||'-'||Substr(sqlerrm, 1, 150);
   End;
   
<<Error>>

   If w_error > 0 Then
      sp_alta_errores_datos_ing_WD(w_Proceso, Pstrabajador, PnLinea, w_desc_error);
      Update bitacora_carga_ing_WD
      Set    Registros_error = Registros_error + 1
      Where  Proceso = w_archivo;

   End If;
   
   Commit;
   Return;

End sp_alta_rel_trab_agr_ING_DW;
/

Create Or Replace Public Synonym sp_alta_rel_trab_agr_ING_DW for sp_alta_rel_trab_agr_ING_DW;
Grant  Execute On sp_alta_rel_trab_agr_ING_DW to adama;
