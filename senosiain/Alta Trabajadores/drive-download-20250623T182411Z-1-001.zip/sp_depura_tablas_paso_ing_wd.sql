Create Or replace Procedure sp_depura_tablas_paso_ing_wd
As
   w_sql  Long;
Begin


    w_sql := 'Truncate table trabajadores_nuevos_ING_WD';
    Execute Immediate w_sql;

    w_sql := 'Truncate table trabajadores_ING_WD';
    Execute Immediate w_sql;
    
    w_sql := 'Truncate table trabajadores_grales_ING_WD';
    Execute Immediate w_sql;

    w_sql := 'Truncate table trabajadores_baja_ING_WD';
    Execute Immediate w_sql;

    w_sql := 'Truncate table inf_complementaria_ING_WD';
    Execute Immediate w_sql;

    w_sql := 'Truncate table sueldos_ING_WD';
    Execute Immediate w_sql;

    w_sql := 'Truncate table rel_trab_agr_ING_DW';
    Execute Immediate w_sql;

    w_sql := 'Truncate table error_registro_ing_WD';
    Execute Immediate w_sql;

    w_sql := 'Truncate table errores_datos_ing_WD';
    Execute Immediate w_sql;

    w_sql := 'Truncate table bitacora_carga_ing_WD';
    Execute Immediate w_sql;

    w_sql := 'Truncate table Debug_procesos_ing_WD';
    Execute Immediate w_sql;


End sp_depura_tablas_paso_ing_wd;
/

Create Or Replace Public Synonym sp_depura_tablas_paso_ing_wd for sp_depura_tablas_paso_ing_wd;
Grant  Execute on sp_depura_tablas_paso_ing_wd to Adama;


