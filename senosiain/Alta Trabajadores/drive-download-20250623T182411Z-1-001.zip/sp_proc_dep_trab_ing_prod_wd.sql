Create or Replace Procedure sp_proc_dep_trab_ing_prod_wd
As
   w_error                  Number(1, 0)  := 0;
   w_desc_error             Varchar2(250);
   w_proceso                Varchar2(030) := 'CUENTA DEPOSITO TRABAJADOR';
   w_sql                    Varchar2(4000);
   w_y                      Number(1, 0)  := 1;
   w_linea                  Number(4, 0);
   w_comilla                Char(1) := Chr(39);
   w_sit_trabajador         Number(1, 0);
   w_Cuenta_deposito        Char(20);
   w_Institucion_deposito   Char(3);

   Cursor C_trab_new Is
   Select Compania, Trabajador, Institucion_deposito, Cuenta_deposito, Linea
   From   trabajadores_grales_ING_WD
   Where  Nvl(Cuenta_deposito, 0) != ' '   
   Order  by Linea;

Begin

   For X1 in C_trab_new Loop
       Begin
          Select Distinct 1
          Into   w_error
          From   bitacora_carga_ing_WD
          Where  Proceso = w_proceso
          And    Rownum  < 2;
          Exception When no_data_found Then
             Insert into bitacora_carga_ing_WD
             Values (w_proceso, 0, 0, 0);
       End;

       Update bitacora_carga_ing_WD
       Set    Registros_leidos = Registros_leidos + 1
       Where  Proceso = w_proceso;
       Commit;

       Begin
          Select Distinct 0, sit_trabajador
          Into   w_error,    w_sit_trabajador
          From   Trabajadores_grales
          Where  Compania   = x1.compania
          And    Trabajador = x1.trabajador
          And    Rownum      < 2;
          Exception When no_data_Found Then
             w_error := 1;
             w_desc_error := 'C�DIGO DE TRABAJADOR NO EXISTE EN TRABAJADORES_GRALES.';
             sp_alta_errores_datos_ing_WD(w_Proceso, x1.trabajador, x1.Linea, w_desc_error);
             Update bitacora_carga_ing_WD
             Set    Registros_error = Registros_error + 1
             Where  Proceso = w_proceso;
             Commit;
       End;

       If w_Sit_trabajador = 2  And
          w_error          = 0 Then
          w_error := 1;
          w_desc_error := 'TRABAJADOR EN SITUACI�N DE BAJA.';
             sp_alta_errores_datos_ing_WD(w_Proceso, x1.trabajador, x1.Linea, w_desc_error);
             Update bitacora_carga_ing_WD
             Set    Registros_error = Registros_error + 1
             Where  Proceso = w_proceso;
             Commit;
       End If;
       
       If w_error = 0 Then
          Begin
             Select institucion_deposito,   cuenta_deposito
             Into   w_institucion_deposito, w_cuenta_deposito
             From   Rel_trab_ins_dep
             Where  Compania          = x1.compania
             And    Trabajador        = x1.trabajador
             And    Ins_dep_principal = 1
             And    Rownum            < 2;
             Exception When no_data_Found Then
                w_institucion_deposito := ' ';
                w_cuenta_deposito      := ' ';
          End;
       End If;

       If w_error = 0 Then
          If w_Institucion_deposito <> x1.Institucion_deposito    Or
             w_Cuenta_deposito      <> x1.Cuenta_deposito       Then
             Update Rel_trab_ins_dep
             Set    Ins_dep_principal = 0
             Where  Compania             = x1.compania
             And    Trabajador           = x1.trabajador
             And    Institucion_deposito = w_Institucion_deposito
             And    Cuenta_deposito      = w_Cuenta_deposito;
             
             Delete Rel_trab_ins_dep
             Where  Compania             = x1.compania
             And    Trabajador           = x1.trabajador
             And    Institucion_deposito = x1.Institucion_deposito
             And    Cuenta_deposito      = x1.Cuenta_deposito;

             Begin
                sp_alta_rel_trab_ins_dep (x1.compania, x1.trabajador, x1.Institucion_deposito, x1.Cuenta_deposito, 1);
                Exception When no_data_Found Then
                   w_error      := 1;
                   w_desc_error := 'ERROR ACTUALIZANDO CUENTA DEPOSITO.';
                   sp_alta_errores_datos_ing_WD(w_Proceso, x1.trabajador, x1.Linea, w_desc_error);
                   Update bitacora_carga_ing_WD
                   Set    Registros_error = Registros_error + 1
                   Where  Proceso = w_proceso;
             End;
             Commit;             
          End If;
       End If;
   End Loop;
   Return;

End sp_proc_dep_trab_ing_prod_wd;
/

Create Or Replace Public Synonym sp_proc_dep_trab_ing_prod_wd for sp_proc_dep_trab_ing_prod_wd;
Grant  Execute on sp_proc_dep_trab_ing_prod_wd to Adama;

