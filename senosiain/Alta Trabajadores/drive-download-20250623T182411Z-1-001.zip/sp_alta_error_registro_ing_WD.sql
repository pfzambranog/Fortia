Create Or Replace Procedure sp_alta_error_registro_ing_WD
  (PsProceso    Varchar2,
   PnLinea      Number,
   PsError      Varchar2,
   PdFecha      Date  Default sysdate)
As
   w_existe     Number(1, 0) := 0;
   w_mensaje    Varchar2(250);
   
Begin

   If Upper(PsError) Like Upper('%Could not find file%') Then
      w_mensaje := 'NO EXISTE ARCHIVO EN DIRECTORIO DE PROCESO';
   Else
      w_mensaje := Substr(PsError, 1, 250);
   End If;
   
   Begin
      Select 1
      Into   w_existe
      From   error_registro_ing_WD
      Where  Proceso = PsProceso
      And    Linea   = PnLinea
      And    Rownum  < 2;
      Exception When no_data_found Then
         w_existe := 0;
   End;
   
   If w_existe = 0 Then
      Insert Into error_registro_ing_WD
      Select PsProceso, PnLinea, Substr(w_mensaje, 1, 250), PdFecha
      From   Dual;
      Commit;
   End If;
   Return;

End sp_alta_error_registro_ing_WD;
/

Create Or Replace Public Synonym sp_alta_error_registro_ing_WD for sp_alta_error_registro_ing_WD;
Grant Execute On sp_alta_error_registro_ing_WD to adama;
