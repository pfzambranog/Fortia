Create or Replace Procedure sp_procesa_edo_civil_ING_WD
As
   w_error                  Number(1, 0)  := 0;
   w_desc_error             Varchar2(250);
   w_proceso                Varchar2(030) := 'ESTADOCIVIL';
   w_sql                    Varchar2(4000);
   w_y                      Number(1, 0)  := 1;
   w_linea                  Number(4, 0);
   w_comilla                Char(1) := Chr(39);
   w_sit_trabajador         Number(1, 0);
   w_dato_01                Varchar(40);

   Cursor C_trab_new Is
   Select Trabajador, Estado_civil, Linea
   From   inf_complementaria_ING_WD
   Order  by Linea;

Begin

   For X1 in C_trab_new Loop
       Begin
          Select Distinct 1
          Into   w_error
          From   bitacora_carga_ing_WD
          Where  Proceso = w_proceso
          And    Rownum  < 2;
          Exception When no_data_found Then
             Insert into bitacora_carga_ing_WD
             Values (w_proceso, 0, 0, 0);
       End;

       Update bitacora_carga_ing_WD
       Set    Registros_leidos = Registros_leidos + 1
       Where  Proceso = w_proceso;
       Commit;

       Begin
          Select Distinct 0
          Into   w_error
          From   Trabajadores
          Where  Trabajador = x1.trabajador
          And    Rownum      < 2;
          Exception When no_data_Found Then
             w_error := 1;
             w_desc_error := 'CODIGO DE TRABAJADOR NO EXISTE EN TRABAJADORES.';
             sp_alta_errores_datos_ing_WD(w_Proceso, x1.trabajador, x1.Linea, w_desc_error);
             Update bitacora_carga_ing_WD
             Set    Registros_error = Registros_error + 1
             Where  Proceso = w_proceso;
             Commit;
       End;

       If w_error = 0 Then
          w_y := 0;
          Begin
             Select Dato_01
             Into   w_dato_01
             From   inf_soc_trabajador
             Where  indice_inf_soc = 'ESTADCIVIL'
             And    trabajador     = x1.trabajador
             And    Rownum         < 2;
             Exception When no_data_found Then
                w_y := 1;
          End;

          If w_y = 0                                                                     And
             Upper(Nvl(trim(w_dato_01), ' ')) <> Upper(Nvl(trim(x1.Estado_civil), ' ')) Then
             sp_baja_inf_soc_trabajador  ( x1.trabajador, 'ESTADCIVIL', Null);
             w_y := 1;
          End if;

          If w_y = 1 Then
             Begin
                sp_alta_inf_soc_trabajador  ( x1.trabajador, 'ESTADCIVIL', Null, x1.estado_civil);
                Exception When Others Then
                  Rollback;
                  w_desc_error := 'ERRROR AL ASIGNAR ESTADO CIVIL.: '||to_char(sqlcode)||'-'||Substr(sqlerrm, 1, 150);
                  sp_alta_errores_datos_ing_WD(w_Proceso, x1.trabajador, x1.Linea, w_desc_error);
                  Update bitacora_carga_ing_WD
                  Set    Registros_error = Registros_error + 1
                  Where  Proceso = w_proceso;
                  Commit;
             End;
          End If;
       End If;
   End Loop;
   Commit;
   Return;

End sp_procesa_edo_civil_ING_WD;
/

Create Or Replace Public Synonym sp_procesa_edo_civil_ING_WD for sp_procesa_edo_civil_ING_WD;
Grant  Execute on sp_procesa_edo_civil_ING_WD to Adama;
