Create Or Replace Procedure Sp_act_interface_dw_ing
As

Begin
   sp_alta_trab_ing_prod_dw;
   sp_alta_inf_comple_ing_prod_dw;
   sp_alta_trab_gral_ing_prod_dw;
   sp_proc_bajas_trab_ing_pro_wd;
   sp_alta_sueldos_Ing_prod_wd;
--   sp_proc_dep_trab_ing_prod_wd;
   sp_proc_var_trab_ing_prod_wd;
   sp_alta_rel_tra_agr_ing_pro_wd;
   sp_procesa_edo_civil_ING_WD;

   sp_proc_pla_trab_ing_prod_wd;

   Update bitacora_carga_ing_WD
   Set    Registros_validos = Registros_leidos - Registros_error;

   Commit;
   Return;
   
End Sp_act_interface_dw_ing;
/

Create or Replace Public Synonym Sp_act_interface_dw_ing For Sp_act_interface_dw_ing;
Grant  Execute On Sp_act_interface_dw_ing to Adama;
