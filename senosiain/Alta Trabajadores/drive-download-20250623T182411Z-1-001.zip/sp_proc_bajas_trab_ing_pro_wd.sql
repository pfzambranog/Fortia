/*

Nota:

Procedimiento actualizado el 30/07/2016, para incluir los movimientos de baja en el historial laboral.

*/

Create Or Replace Procedure sp_proc_bajas_trab_ing_pro_wd
As
   w_error                  Number(1, 0)  := 0;
   w_desc_error             Varchar2(250);
   w_proceso                Varchar2(030) := 'ARCHIVO TRABAJADORES_BAJA.TXT';
   w_archivo                Varchar2(030) := 'TRABAJADORES_BAJA.TXT';
   w_sql                    Varchar2(4000);
   w_y                      Number(1, 0)  := 1;
   w_linea                  Number(4, 0);
   w_comilla                Char(1)       := Chr(39);

   w_sit_trabajador         Number(1, 0);
   w_fecha_baja             Date;
   w_causa_baja             Char(1);
   w_descripcion            Char(40);
   w_descripcion_param      Char(40);
   w_fecha_proc             Date          := Sysdate;

   Cursor C_trab_new Is
   Select *
   From   trabajadores_baja_ING_WD
   Order  by Linea;

Begin


   For X1 in C_trab_new Loop
       w_error := 0;

       Begin
          Select sit_trabajador,   fecha_baja,  w_causa_baja
          Into   w_sit_trabajador, w_fecha_baja, w_causa_baja
          From   Trabajadores_grales
          Where  Compania   = x1.compania
          And    Trabajador = x1.trabajador
          And    Rownum      < 2;
          Exception When no_data_Found Then
             w_error := 1;
             w_desc_error := 'C�DIGO DE TRABAJADOR NO EXISTE EN TRABAJADORES_GRALES.';
             sp_alta_errores_datos_ing_WD(w_Proceso, x1.trabajador, x1.Linea, w_desc_error);
             Update bitacora_carga_ing_WD
             Set    Registros_error = Registros_error + 1
             Where  Proceso = w_archivo;
             Commit;
       End;

       If w_error = 0 Then
          If w_sit_trabajador = 1 Then
             w_error      := 0;
             w_desc_error := Null;
             Sp_ing_valida_transacciones(x1.compania, x1.compania, w_error, w_desc_error);
             If w_error <> 0 Then
                sp_alta_errores_datos_ing_WD(w_Proceso, x1.trabajador, x1.Linea, w_desc_error);
                Update bitacora_carga_ing_WD
                Set    Registros_error = Registros_error + 1
                Where  Proceso = w_archivo;
                Commit;
             End If;
          End if;

          If w_error = 0 Then
             w_y := 0;

             w_sql := 'Update Trabajadores_grales '||
                      'Set    ';

             If w_sit_trabajador = 1 Then
                w_y := 1;
                w_sql := w_sql|| ' Sit_trabajador = 2 ';
             End If;

             If Nvl(w_fecha_baja, Sysdate) <> Nvl(x1.fecha_baja, Sysdate) Then
                If w_y = 1 Then
                   w_sql := w_sql||', ';
                Else
                   w_y := 1;
                End If;

                w_sql := w_sql || ' fecha_baja = '||w_comilla||to_char(Nvl(x1.fecha_baja, Sysdate))||w_comilla;
             End If;

             If Nvl(w_causa_baja, ' ') <> Nvl(x1.causa_baja, ' ') Then
                If w_y = 1 Then
                   w_sql := w_sql||', ';
                Else
                   w_y := 1;
                End If;

                w_sql := w_sql || ' causa_baja = '||w_comilla||Nvl(x1.causa_baja, ' ')||w_comilla;
             End If;

             If w_y = 1 Then
                Begin
                   w_sql := w_sql ||' Where Compania   = '||w_comilla||x1.Compania  ||w_comilla||
                                    ' And   Trabajador = '||w_comilla||x1.trabajador||w_comilla;
                   Execute Immediate w_sql;
                   Exception When Others Then
                      Rollback;
                      w_desc_error := 'ERRROR AL INSERTAR REGISTRO.: '||to_char(sqlcode)||'-'||Substr(sqlerrm, 1, 150);
                      sp_alta_errores_datos_ing_WD(w_Proceso, x1.trabajador, x1.Linea, w_desc_error);
                      Update bitacora_carga_ing_WD
                      Set    Registros_error = Registros_error + 1
                      Where  Proceso = w_archivo;
                End;
                Commit;

                Begin
                   Select descripcion
                   Into   w_descripcion
                   From   Causas_baja
                   Where  causa_baja = x1.causa_baja
                   And    rownum    < 2;
                   Exception When no_data_found Then
                     w_descripcion := ' ';
                End;

                Begin
                   Select descripcion
                   Into   w_descripcion_param 
                   From   Parametros_rh
                   Where  compania      = x1.Compania
                   And    parametro_rh  = 'Inc_HL_DG' 
                   And    Secuencia_parametro = 2
                   And    Entero              = 2 
                   And    Rownum              < 2;
                   Exception When no_data_found Then
                      w_descripcion_param := 'Baja del Trabajador';
                End;

                sp_alta_historial_laboral  ( x1.Compania,         x1.trabajador, 'DG', '0000000002',  w_fecha_proc,  Null,
                                             w_descripcion_param, Null,          Null, w_fecha_proc,  w_descripcion);

                sp_alta_hist_bajas  (x1.Compania, x1.trabajador, w_fecha_proc, x1.causa_baja);

                sp_alta_hist_bajas_enc  (x1.Compania, x1.trabajador, w_fecha_proc, x1.causa_baja, x1.causa_baja, 1);

                sp_alta_hist_bajas_det  (x1.Compania, x1.trabajador, w_fecha_proc, 1, w_descripcion, 1 );

                sp_gen_stat_ha_trab  (x1.Compania, x1.trabajador);

             End If;
          End If;
       End If;
   End Loop;
   Commit;
   Return;

End sp_proc_bajas_trab_ing_pro_wd;
/

Create Or Replace Public Synonym sp_proc_bajas_trab_ing_pro_wd for sp_proc_bajas_trab_ing_pro_wd;
Grant  Execute on sp_proc_bajas_trab_ing_pro_wd to Adama;


