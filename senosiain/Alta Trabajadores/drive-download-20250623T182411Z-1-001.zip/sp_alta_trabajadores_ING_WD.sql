Create Or replace Procedure sp_alta_trabajadores_ING_WD
  (Pstrabajador          Char,
   Psregistro_fiscal     Varchar2,
   Psnombre              Varchar2,
   Psnombre_abreviado    Varchar2,
   PnSexo                Number,
   Pdfecha_nacimiento    Char,
   Psdomicilio           Varchar2,
   Psdomicilio2          Varchar2,
   Pspoblacion           Varchar2,
   Psestado_provincia    Varchar2,
   Pspais                Varchar2,
   Pscodigo_postal       Varchar2,
   Pscalles_aledanas     Varchar2,
   Pstelefono_particular Varchar2,
   Psreg_seguro_social   Varchar2,
   Psdomicilio3          Varchar2,
   Psclave_unica         Varchar2,
   Pse_mail              Varchar2,
   PnLinea               Number)

As
   w_trabajador          Char(10) := Lpad(trim(PsTrabajador), 10, ' ');
   w_fecha_nacimiento    Date;
   w_error               Numeric(1, 0) := 0;
   w_desc_error          Varchar2(250);
   w_proceso             Varchar2(030) := 'ARCHIVO TRABAJADORES.TXT';
   w_archivo             Varchar2(030) := 'TRABAJADORES.TXT';
   w_len                 Numeric(3, 0) := 0;
   w_x                   Numeric(3, 0) := 1;
   w_y                   Numeric(1, 0) := 0;
   w_linea               Numeric(4, 0) := 0;

Begin

   Begin
      Select distinct 1
      Into   w_y
      From   bitacora_carga_ing_WD
      Where  Proceso = w_archivo
      And    Rownum  < 2;
      Exception When no_data_found Then
        w_y := 0;
   End;

   If w_y = 0 Then
      Insert Into bitacora_carga_ing_WD
      Select w_archivo, 1, 0, 0
      From   Dual;
   Else
      w_y := 0;
      Update bitacora_carga_ing_WD
      Set    Registros_leidos = nvl(registros_leidos, 0) + 1
      Where  Proceso = w_archivo;
   End If;

   Commit;

   Begin
      Select to_date(Pdfecha_nacimiento, 'dd/mm/yyyy')
      Into   w_fecha_nacimiento
      From   dual;
      Exception when Others Then
         w_error := 1;
         w_desc_error := 'FORMATO DE FECHA DE NACIMIENTO NO VALIDO';
   End;

   If w_error = 0 Then
      If w_fecha_nacimiento >= sysdate Then
         w_error := 1;
         w_desc_error := 'FECHA DE NACIMIENTO > FECHA DE PROCESO';
      End If;
   End If;

   If w_error = 0 Then
      If Nvl(PnSexo, 0) Not In (1, 2) Then
         w_error := 1;
         w_desc_error := 'CODIGO DE SEXO NO VALIDO';
      End If;
   End If;

   If w_error = 0 Then
      w_len := length(psNombre);

      While w_x <= w_len Loop
         If Substr(PsNombre, w_x, 1) = '/' Then
            w_y := w_y + 1;
            If w_y > 2 Then
               w_x := w_len;
            End If;

         End If;
         w_x := w_x + 1;
      End Loop;

      If w_y <> 2 Then
         w_error := 1;
         w_desc_error := 'FORMATO DE NOMBRE INVALIDO. CANTIDAD DE / ES DIFERENTE A DOS.';
      End If;
   End If;

   If w_error = 0 Then
      Begin
         Select linea
         Into   w_linea
         From   trabajadores_ING_WD
         Where  Trabajador = w_Trabajador
         And    Rownum < 2;
         Exception When no_data_found Then
            w_linea := 0;
      End;

   End If;

   If w_linea > 0 Then
      w_error := 1;
      w_desc_error := 'CODIGO DE TRABAJADOR PRESENTE ANTERIORMENTE EN LA L�NEA '||to_char(w_linea);
   End If;

   If w_error = 0 Then
      Begin
         Insert into trabajadores_ING_WD
         Select w_trabajador,                     Psregistro_fiscal,     Psnombre,                    Psnombre_abreviado,
                PnSexo,                           w_fecha_nacimiento,    Substr(Psdomicilio, 1, 40),  Substr(Psdomicilio2, 1, 40),
                Pspoblacion,                      Psestado_provincia,    Pspais,                      Pscodigo_postal,
                Substr(Pscalles_aledanas, 1, 40), Pstelefono_particular, Psreg_seguro_social,         Substr(Psdomicilio3, 1, 30),
                Psclave_unica,                    Pse_mail,              PnLinea
         From   Dual;

         Update bitacora_carga_ing_WD
         Set    Registros_validos  = Registros_validos  + 1
         Where  Proceso = w_archivo;

         Commit;
         Exception When Others Then
            Rollback;
            w_error      := 1;
            w_desc_error := 'ERRROR AL INSERTAR REGISTRO.: '||to_char(sqlcode)||'-'||Substr(sqlerrm, 1, 150);
      End;
   End If;

   If w_error > 0 Then
      sp_alta_errores_datos_ing_WD(w_Proceso, Pstrabajador, PnLinea, w_desc_error);
      Update bitacora_carga_ing_WD
      Set    Registros_error = Registros_error + 1
      Where  Proceso = w_archivo;

   Else
      Begin
         Select 1
         Into   w_y
         From   trabajadores
         Where  Trabajador = w_trabajador
         And    Rownum     < 2;
         Exception When no_data_found Then
            w_y := 0;
      End;

      If w_y = 0 Then
         Insert Into trabajadores_nuevos_ING_WD
         Values ('04', PsTrabajador, PsNombre);
         Commit;
      End If;

   End If;

End sp_alta_trabajadores_ING_WD;
/

Create Or Replace Public Synonym sp_alta_trabajadores_ING_WD for sp_alta_trabajadores_ING_WD;
Grant  Execute on sp_alta_trabajadores_ING_WD to Adama;
