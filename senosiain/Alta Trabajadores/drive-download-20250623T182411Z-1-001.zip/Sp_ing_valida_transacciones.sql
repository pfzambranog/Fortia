Create Or Replace Procedure Sp_ing_valida_transacciones
  (PsCompania   Char,
   PsTrabajador Char,
   pnError      In Out Number,
   PsDesc_error In Out Varchar)
As

Begin

   Begin
      Select Distinct 1
      Into   pnError
      From   Transacciones_ns
      Where  Compania   = PsCompania
      And    Trabajador = PsTrabajador
      And    Rownum     < 2;
      Exception When no_data_found Then
         pnError := 0;
   End;


   Begin
      Select Distinct 2
      Into   pnError
      From   transacciones_indiv
      Where  Compania   = PsCompania
      And    Trabajador = PsTrabajador
      And    Rownum     < 2;
      Exception When no_data_found Then
            pnError      := 0;
   End;

   If pnError = 1 Then     
      PsDesc_error := 'TRABAJADOR TIENE TRANSACCIONES INDIVIDUALES DE NOMINA';
      Goto Salida;
   End If;

   Begin
      Select Distinct 3
      Into   pnError
      From   transacciones_ptes
      Where  Compania   = PsCompania
      And    Trabajador = PsTrabajador
      And    Rownum     < 2;
      Exception When no_data_found Then
         pnError      := 0;
   End;

   If pnError = 3 Then     
      PsDesc_error := 'TRABAJADOR TIENE TRANSACCIONES PENDIENTES DE NOMINA';
   End If;


<<Salida>>   
   Return;
   
End Sp_ing_valida_transacciones;
/


Create Or Replace Public Synonym Sp_ing_valida_transacciones for Sp_ing_valida_transacciones;
Grant  Execute on Sp_ing_valida_transacciones to Adama;

