Create Or Replace Procedure sp_alta_trab_baja_ING_WD
     (pscompania             Char,
      Pstrabajador           Char,
      Psfecha_baja           Char,
      Pscausa_baja           Char,
      PnLinea                Number)
As

   w_trabajador             Char(10)      := Lpad(trim(PsTrabajador), 10, ' ');
   w_error                  Number(1, 0)  := 0;
   w_desc_error             Varchar2(250);
   w_proceso                Varchar2(030) := 'ARCHIVO TRABAJADORES_BAJA.TXT';
   w_archivo                Varchar2(030) := 'TRABAJADORES_BAJA.TXT';
   w_fecha_baja             Date;
   w_y                      Number(1, 0)  := 0;
   w_linea                  Number(4, 0);

Begin
   Begin
      Select distinct 1
      Into   w_y
      From   bitacora_carga_ing_WD
      Where  Proceso = w_archivo
      And    Rownum  < 2;
      Exception When no_data_found Then
        w_y := 0;
   End;
   
   If w_y = 0 Then
      Insert Into bitacora_carga_ing_WD
      Select w_archivo, 1, 0, 0
      From   Dual;
   Else
      w_y := 0;
      Update bitacora_carga_ing_WD
      Set    Registros_leidos = registros_leidos + 1
      Where  Proceso = w_archivo;
   End If;

   Commit;

   Begin
      Select to_date(substr(trim(Psfecha_baja), 1, 10), 'dd-mm-yyyy')
      Into   w_fecha_baja
      From   dual;
      Exception when Others Then
         w_error      := 1;
         w_desc_error := 'FORMATO DE FECHA DE BAJA NO VALIDO.: '||Chr(39)||Psfecha_baja||Chr(39);
         Goto Error;
   End;
   
   Begin
      Select 1
      Into   w_y
      From   causas_baja
      Where  causa_baja = Pscausa_baja 
      And    Rownum     < 2;
      Exception When no_data_found Then
         w_error      := 1;
         w_desc_error := 'CODIGO DE CAUSA BAJA NO VALIDO.: ' ||Nvl(Pscausa_baja, ' ' );
         Goto Error;
   End;
   
   Begin
      Select 1
      Into   w_y
      From   Companias
      Where  Compania = PsCompania
      And    Rownum   < 2;
      Exception When no_data_found Then
         w_error      := 1;
         w_desc_error := 'CODIGO DE COMPA�IA NO VALIDO.: ' ||Nvl(PsCompania, ' ' );
         Goto Error;
   End;

   Begin
      Select linea
      Into   w_linea
      From   trabajadores_baja_ING_WD
      Where  Trabajador = PsTrabajador
      And    Rownum < 2;
      Exception When no_data_found Then
            w_linea := 0;
   End;
   
   If w_linea > 0 Then
      w_error := 1;
      w_desc_error := 'CODIGO DE TRABAJADOR PRESENTE ANTERIORMENTE EN LA LINEA '||to_char(w_linea);
      Goto Error;
   End If;
   
   Begin
      Insert Into trabajadores_baja_ING_WD
      Values (pscompania, w_trabajador, w_fecha_baja, Pscausa_baja, PnLinea);

      Update bitacora_carga_ing_WD
      Set    Registros_validos  = Registros_validos  + 1
      Where  Proceso = w_archivo;

      Exception When Others Then
         Rollback;
         w_error      := 1;
         w_desc_error := 'ERRROR AL INSERTAR REGISTRO.: '||to_char(sqlcode)||'-'||Substr(sqlerrm, 1, 150);
   End;

<<Error>>

   If w_error > 0 Then
      sp_alta_errores_datos_ing_WD(w_Proceso, Pstrabajador, PnLinea, w_desc_error);

      Update bitacora_carga_ing_WD
      Set    Registros_error = Registros_error + 1
      Where  Proceso = w_archivo;
   End If;
   Commit;
   Return;
   
End sp_alta_trab_baja_ING_WD;
/

Create Or Replace Public Synonym sp_alta_trab_baja_ING_WD for sp_alta_trab_baja_ING_WD;
Grant Execute on sp_alta_trab_baja_ING_WD to Adama;
