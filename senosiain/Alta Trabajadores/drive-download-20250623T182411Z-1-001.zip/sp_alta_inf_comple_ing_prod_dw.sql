Create Or Replace Procedure sp_alta_inf_comple_ing_prod_dw
As

   w_trabajador     Char(10);
   w_x              Number(1, 0);
   w_y              Number(1, 0);
   w_error          Number(1, 0)  := 0;
   w_sql            Long;
   w_comilla        Char(1) := Chr(39);
   w_desc_error     Varchar2(250);
   w_proceso        Varchar2(040) := 'ARCHIVO INF_COMPLEMENTARIA.TXT';
   w_archivo        Varchar2(040) := 'INF_COMPLEMENTARIA.TXT';

  
   Cursor C_trab_new Is
   Select *
   From   inf_complementaria_ING_WD
   Order  by Linea;
   
   Cursor C_trabajadores Is
   Select *
   From   inf_complementaria
   Where  Trabajador = w_trabajador;

Begin

   For X1 in C_trab_new Loop
       w_trabajador := x1.trabajador;
       w_error := 0;

       Begin
          Select Distinct 0
          Into   w_x
          From   Trabajadores
          Where  Trabajador = x1.trabajador
          And    Rownum      < 2;
          Exception When no_data_Found Then
             w_error := 1;
             w_desc_error := 'C�DIGO DE TRABAJADOR NO EXISTE EN TRABAJADORES.';
             sp_alta_errores_datos_ing_WD(w_Proceso, x1.trabajador, x1.Linea, w_desc_error);
             Update bitacora_carga_ing_WD
             Set    Registros_error = Registros_error + 1
             Where  Proceso = w_archivo;
             Commit;
       End;
       
       If w_error = 0 Then
          Begin
             Select Distinct 1
             Into   w_x
             From   inf_complementaria
             Where  Trabajador = w_trabajador
             And    Rownum      < 2;
             Exception When no_data_found Then
                w_x := 0;
          End;

          If w_x = 0 Then
             Begin
                Insert Into inf_complementaria
               (trabajador,           lugar_nacimiento,   nacionalidad,    estatura,   peso,   color_pelo,   Color_ojos, tez,
                senas_particulares)
                Select x1.trabajador,         x1.lugar_nacimiento,  x1.nacionalidad, x1.estatura, x1.peso, x1.color_pelo, x1.Color_ojos, x1.tez,
                       x1.senas_particulares
                From   Dual;
                Exception When Others Then
                   Rollback;
                   w_desc_error := 'ERRROR AL INSERTAR REGISTRO.: '||to_char(sqlcode)||'-'||Substr(sqlerrm, 1, 150);
                   sp_alta_errores_datos_ing_WD(w_Proceso, x1.trabajador, x1.Linea, w_desc_error);
                   Update bitacora_carga_ing_WD
                   Set    Registros_error = Registros_error + 1
                   Where  Proceso = w_archivo;
             End;
             Commit;
          Else
             Begin
                For X2 In C_Trabajadores Loop
                    w_sql := 'Update inf_complementaria ' ||
                             'Set    ';
                    w_y := 0;
                 
                    If Nvl(x1.lugar_nacimiento, ' ') <> Nvl(x2.lugar_nacimiento, ' ') Then
                       If w_y = 1 Then
                          w_sql := w_sql ||', ';
                       Else
                          w_y := 1;
                       End If;
                    
                       w_sql := w_sql||' lugar_nacimiento = ';
                       If x1.lugar_nacimiento Is Null Then
                          w_sql := w_sql||' Null ';
                       Else
                          w_sql := w_sql ||w_comilla||trim(x1.lugar_nacimiento)||w_comilla;
                       End If;
                    End If;
                 
                    If Nvl(x1.nacionalidad, ' ') <> Nvl(x2.nacionalidad, ' ') Then
                       If w_y = 1 Then
                          w_sql := w_sql ||', ';
                       Else
                          w_y := 1;
                       End If;
                     
                       w_sql := w_sql||' nacionalidad = ';
                       If x1.nacionalidad Is Null Then
                          w_sql := w_sql||' Null ';
                       Else
                          w_sql := w_sql ||w_comilla||trim(x1.nacionalidad)||w_comilla;
                       End If;
                    End If;

                    If Nvl(x1.estatura, 0) <> Nvl(x2.estatura, 0) Then
                       If w_y = 1 Then
                          w_sql := w_sql ||', ';
                       Else
                          w_y := 1;
                       End If;
                  
                       w_sql := w_sql||' estatura = ';
                       If x1.estatura Is Null Then
                          w_sql := w_sql||' Null ';
                       Else
                          w_sql := w_sql ||w_comilla||to_char(x1.estatura)||w_comilla;
                       End If;
                    End If;

                    If Nvl(x1.peso, 0) <> Nvl(x2.peso, 0) Then
                       If w_y = 1 Then
                          w_sql := w_sql ||', ';
                       Else
                          w_y := 1;
                       End If;
                    
                       w_sql := w_sql||' peso = ';
                       If x1.peso Is Null Then
                          w_sql := w_sql||' Null ';
                       Else
                          w_sql := w_sql ||w_comilla||to_char(x1.peso)||w_comilla;
                       End If;
                    End If;

                    If Nvl(x1.color_pelo, ' ') <> Nvl(x2.color_pelo, ' ') Then
                       If w_y = 1 Then
                          w_sql := w_sql ||', ';
                       Else
                          w_y := 1;
                       End If;
                    
                       w_sql := w_sql||' color_pelo = ';
                       If x1.color_pelo Is Null Then
                           w_sql := w_sql||' Null ';
                        Else
                           w_sql := w_sql ||w_comilla||trim(x1.color_pelo)||w_comilla;
                        End If;
                     End If;

                     If Nvl(x1.Color_ojos, ' ') <> Nvl(x2.Color_ojos, ' ') Then
                        If w_y = 1 Then
                           w_sql := w_sql ||', ';
                        Else
                           w_y := 1;
                        End If;
                  
                        w_sql := w_sql||' Color_ojos = ';
                        If x1.Color_ojos Is Null Then
                           w_sql := w_sql||' Null ';
                        Else
                           w_sql := w_sql ||w_comilla||trim(x1.Color_ojos)||w_comilla;
                        End If;
                     End If;

                     If Nvl(x1.tez, ' ') <> Nvl(x2.tez, ' ') Then
                        If w_y = 1 Then
                           w_sql := w_sql ||', ';
                        Else
                           w_y := 1;
                        End If;

                        w_sql := w_sql||' tez = ';
                        If x1.tez Is Null Then
                           w_sql := w_sql||' Null ';
                        Else
                           w_sql := w_sql ||w_comilla||trim(x1.tez)||w_comilla;
                        End If;
                     End If;

                     If Nvl(x1.senas_particulares, ' ') <> Nvl(x2.senas_particulares, ' ') Then
                        If w_y = 1 Then
                           w_sql := w_sql ||', ';
                        Else
                           w_y := 1;
                        End If;
                    
                        w_sql := w_sql||' senas_particulares = ';
                        If x1.senas_particulares Is Null Then
                           w_sql := w_sql||' Null ';
                        Else
                           w_sql := w_sql ||w_comilla||trim(x1.senas_particulares)||w_comilla;
                        End If;
                     End If;

                     If w_y = 1 Then
                        Begin
                           w_sql := w_sql ||' Where Trabajador = '||w_comilla||w_trabajador||w_comilla;
                           Execute Immediate w_sql;
                           Exception When Others Then
                              Rollback;
                              w_desc_error := 'ERRROR AL INSERTAR REGISTRO.: '||to_char(sqlcode)||'-'||Substr(sqlerrm, 1, 150);
                              sp_alta_errores_datos_ing_WD(w_Proceso, x1.trabajador, x1.Linea, w_desc_error);
                              Update bitacora_carga_ing_WD
                              Set    Registros_error = Registros_error + 1
                              Where  Proceso = w_archivo;
                        End;
                        Commit;
                     End If;
                   
                End Loop;
             End;

          End If;
       End If;

   End Loop;
   Return;
End sp_alta_inf_comple_ing_prod_dw;
/

Create Or Replace Public Synonym sp_alta_inf_comple_ing_prod_dw for sp_alta_inf_comple_ing_prod_dw;
Grant  Execute On sp_alta_inf_comple_ing_prod_dw to adama;