if OBJECT_ID('fn_sueldo_prom_gratif')is not null
drop function fn_sueldo_prom_gratif
go 
  
create function fn_sueldo_prom_gratif
(  
@cla_emp int,  
@cla_trab int, 
@cla_per	int, 
@folio_nom	int
)  
  
returns float  
as  
begin  
  
   declare @importe float 

   select @importe = SUM(importe) 
   from RH_DET_REC_ACTUAL 
   where CLA_TRAB = @cla_trab
   and CLA_EMPRESA = @cla_emp
   and FOLIO_NOM = @folio_nom
   and CLA_PERIODO =@cla_per
   and CLA_PERDED = 10214
  
  if ISNULL(@importe,0)= 0

   select @importe = SUM(importe) 
   from RH_DET_REC_ACTUAL 
   where CLA_TRAB = @cla_trab
   and CLA_EMPRESA = @cla_emp
   and FOLIO_NOM = @folio_nom
   and CLA_PERIODO =@cla_per
   and CLA_PERDED = 10213
   
 return isnull(@importe,0)  
  
end