/*funci�n para calculo de ingresos por gratificaci�n*/

if OBJECT_ID('fn_ingresos_gratif')is not null
drop function fn_ingresos_gratif
go 
  
create function fn_ingresos_gratif
(  
@cla_emp int,  
@cla_trab int, 
@cla_per	int, 
@folio_nom	int
)  
  
returns float  
as  
begin  
  
 declare   
 @resultado float,  
 @importe float,  
 @inicio  int,  
 @fin  int,  
 @dias_per float,  
 @dias_anu int  
  
 select @inicio = isnull(VALOR_VAR_USUARIO,0)  
 from RH_VAR_USUARIO  
 where CLA_VAR  = '$in_GS_PTU'  --- a�o mes inicio aaaamm $in_GS_PTU a�o mes inicio
 and  CLA_EMPRESA = @cla_emp  
  
 select @fin = isnull(VALOR_VAR_USUARIO,0)  
 from RH_VAR_USUARIO  
 where CLA_VAR  = '$fi_GS_PTU'  --- a�o mes fin aaaamm $fi_GS_PTU a�o mes fin
 and  CLA_EMPRESA = @cla_emp  
  
 select @importe = isnull(sum(IMPORTE),0)  
 from RH_DET_REC_HISTO  
 where CLA_EMPRESA = @cla_emp  
 and  CLA_TRAB = @cla_trab  
 and  CLA_PERIODO = @cla_per  
 and  ANIO_MES between @inicio and @fin  
 and  CLA_PERDED in (select VALOR_VAR_USUARIO  
         from  RH_VAR_USUARIO  
         where CLA_VAR  = '$prdGSPTU' --- conceptos que deben sumar para el salario promedio son / descontar el importe de los siguientes conceptos
         and  CLA_EMPRESA = @cla_emp)  

return @importe
  
 select @importe += isnull(sum(IMPORTE),0)  
 from RH_DET_REC_ACTUAL  
 where CLA_EMPRESA = @cla_emp  
 and  CLA_TRAB = @cla_trab  
 and  CLA_PERIODO = @cla_per  
 and  CONCAT(DATEPART(YEAR,FECHA_APLICA),right(concat('00', MONTH(FECHA_APLICA)),2)) between @inicio and @fin  
 and  CLA_PERDED in (select VALOR_VAR_USUARIO  
         from  RH_VAR_USUARIO  
         where CLA_VAR  = '$prdGSPTU'  
         and  CLA_EMPRESA = @cla_emp)  
   
  
  
  
 select @dias_anu = isnull(VALOR_VAR_USUARIO,0)  
 from RH_VAR_USUARIO  
 where CLA_VAR  = '$diasG_PTU'  --- 	DIAS ANUAL GRATSEM Para el caso de PTU considera 153 d�as diasG_PTU
 and  CLA_EMPRESA = @cla_emp  
  

  /*No se concidera para el calulo de la gratif especial de PTU
 select @dias_per = isnull(VALOR_VAR_USUARIO,0)  
 from RH_VAR_USUARIO  
 where CLA_VAR  = '$dia_pe_GS'  
 and  CLA_EMPRESA = @cla_emp  
  */

 select @resultado = (@importe / @dias_anu)   
  
   
 return isnull(@importe,0)  
  
end
