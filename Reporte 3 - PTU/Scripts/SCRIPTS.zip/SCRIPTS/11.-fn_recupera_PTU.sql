if OBJECT_ID('fn_recupera_PTU')is not null
drop function fn_recupera_PTU
go 
  
create function fn_recupera_PTU
(  
@cla_emp int,  
@cla_trab int, 
@cla_per	int, 
@folio_nom	int
)  
  
returns float  
as  
begin  
  
   declare  @ANIO INT
		,@importe FLOAT 

   select @ANIO = ANIO_MES_ISPT/100 
   from RH_ENC_REC_ACTUAL 
   where CLA_TRAB = @cla_trab
   and CLA_EMPRESA = @cla_emp
   and FOLIO_NOM = @folio_nom
   and CLA_PERIODO =@cla_per

  
 

   select @importe = SUM(importe) 
   from RH_DET_REC_HISTO t1
   INNER JOIN RH_PERDED T2 
   ON t1.CLA_EMPRESA = T2.CLA_EMPRESA
   AND t1.CLA_PERDED = T2.CLA_PERDED
   where CLA_TRAB = @cla_trab
   and T1.CLA_EMPRESA = @cla_emp
   and CLA_PERIODO =@cla_per
   and ANIO_MES/100 = @ANIO
   AND T2.CLASIFICACION = 18 --SOLO PTU
   AND T2.NO_AFECTAR_NETO = 0 -- QUE AFECTEN AL NETO. 
   
 return isnull(@importe,0)  
  
end