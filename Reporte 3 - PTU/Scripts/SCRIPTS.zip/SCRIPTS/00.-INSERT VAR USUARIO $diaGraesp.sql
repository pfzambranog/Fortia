
DELETE RHCFG_VARIABLE WHERE CLA_VAR = '$diaGraesp'


insert into [RHCFG_VARIABLE] ([CLA_VAR], [DESC_VAR], [EXP_SQL], [TIPO_VAR], [TIPO_REFER1], [TIPO_REFER2], [TIPO_REFER3], [TIPO_REFER4], [TIPO_REFER5], [TIPO_REFER6], [TIPO_REFER7], [TIPO_REFER8], [TIPO_REFER9], [TIPO_REFER10], [SQLREF1], [FECHA_ULT_CAMBIO]) 
values ('$diaGraesp', 'DIAS GRATIFICACION ESPECIAL', '$diaGraesp', 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', GETDATE())
 

insert into [RH_VAR_USUARIO] (CLA_VAR,LLAVE_REFER, CLA_EMPRESA, VALOR_VAR_USUARIO, FECHA_ULT_CAMBIO) 
		select '$diaGraesp', '', 1, 130, GETDATE()
 

 select * from RH_VAR_USUARIO where CLA_VAR = '$diaGraesp'
  select * from [RHCFG_VARIABLE] where CLA_VAR = '$diaGraesp'